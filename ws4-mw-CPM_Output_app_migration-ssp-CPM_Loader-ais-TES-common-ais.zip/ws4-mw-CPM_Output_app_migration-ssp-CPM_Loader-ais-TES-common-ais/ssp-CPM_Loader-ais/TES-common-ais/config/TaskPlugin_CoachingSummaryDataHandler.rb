CoachingSummaryDataHandler = {
  "enabled" => true,
}
