CoachingTipHistoryReceiver = {
  "enabled" => true,
}
