# Loader Payload System: ROS2 Migration of SCS Communication

## Overview

The Job Manager (`LpsSaJobMgrApp`) and Weighing application (`LpsSaWeighApp`) exchange commands, responses, telemetry, and supporting machine data. Historically, these interfaces used AIS SCS (Shared Memory Communication Service), which couples communicating processes to the local SCS runtime.

The migration moves the selected application interfaces to ROS2/DDS topics. JobMgr and WeighApp use ROS2 publishers and subscribers for these migrated channels instead of binding their SCS equivalents. `ScsToRos2Bridge` converts messages between the legacy SCS interfaces and ROS2 topics in both directions. This lets the two applications communicate over ROS2 while existing SCS producers and consumers continue to use their established interfaces.

The bridge itself still runs with AIS SCS to bind the legacy side. The migration does not remove SCS from every application or every machine interface; channels outside the routes listed below may remain on SCS or other local interfaces.

## What Changed

- Migrated channel payloads are represented by generated ROS2 message types.
- JobMgr and WeighApp publish and subscribe to ROS2 topics for their migrated interfaces.
- `ScsToRos2Bridge` owns the corresponding legacy SCS bindings and converts fields between SCS structures and ROS2 messages.
- The bridge forwards each route in its configured direction. `DataLinkDataInput` is published to two ROS2 topics because JobMgr and WeighApp use different message representations.
- Application behavior is not the goal of this change: weighing/calibration calculations, job tracking, state machines, and timing remain in their applications.

## SCS-to-ROS2 Routes

| SCS interface | ROS2 topic | ROS2 message type | Data carried / purpose |
|---|---|---|---|
| `LpsSaJobMgrReqstChannelInput` | `lps_sa_job_mgr_reqst_channel` | `cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel` | Legacy Job Manager requests and commands. |
| `AisJhm2TxChannelInput` | `ais_jhm2_tx_channel` | `cpm_common_interfaces::msg::AisJhm2TxChannel` | JHM2 dispatch and truck state. |
| `SwitchInputScsInput` | `switch_input_scs` | `job_mgr_interfaces::msg::SwitchInputScs` | Physical switch, store-button, and tip-off input states. |
| `LpsSaWeighReqstChannelInput` | `lps_sa_weigh_reqst_channel` | `cpm_common_interfaces::msg::LpsSaWeighReqstChannel` | Weighing commands, request identity, and arguments. |
| `ShmClockInput` | `shm_clock_input` | `cpm_common_interfaces::msg::ShmClockInput` | Service hour meter, UTC offset, and timezone. |
| `DisplayStateInput` | `lps_sa_ui_display_state_interface` | `cpm_common_interfaces::msg::LpsSaUIDisplayStateInterface` | UI display state and verification mode. |
| `DataLinkDataInput` | `data_link_data` | `job_mgr_interfaces::msg::DataLinkData` | JobMgr's datalink data, including store, tip-off, and manual-add signals. |
| `DataLinkDataInput` | `weigh_app_data_link_data` | `weigh_app_interfaces::msg::DataLinkData` | WeighApp datalink representation, including its wider typed and engineering values. |
| `AutonomyConditionDiagnosticsTxChannelInput` | `autonomy_condition_diagnostics_tx_channel` | `cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel` | Autonomy/SEA feature-license status. |
| `EventDiagnosticDataInput` | `event_diagnostic_data` | `job_mgr_interfaces::msg::EventDiagnosticData` | Diagnostic events, faults, and related status. |
| `CalMgrCmdReqstInput` | `cal_mgr_cmd_reqst` | `weigh_app_interfaces::msg::CalMgrCmdReqst` | Calibration-manager commands from SCS-side diagnostics. |
| `DemoAppTxChannelInput` | `demo_app_tx_channel` | `weigh_app_interfaces::msg::DemoAppTxChannel` | Demo and sensor-playback inputs. |
| `PartNumbersInput` | `part_numbers` | `weigh_app_interfaces::msg::PartNumbers` | Product, software, and equipment part numbers. |
| `SystemHardwareHealthInput` | `system_hardware_health` | `weigh_app_interfaces::msg::SystemHardwareHealthStorage` | Hardware and sensor-health status. |
| `PrinterCnfgInput` | `lps_sa_totals_printer_cnfg` | `weigh_app_interfaces::msg::LpsSaTotalsPrinterCnfg` | Printer configuration from the legacy Totals application. |

## ROS2-to-SCS Routes

| ROS2 topic | SCS interface | ROS2 message type | Data carried / purpose |
|---|---|---|---|
| `lps_sa_job_mgr_resp_channel` | `LpsSaJobMgrRespChannelOutput` | `job_mgr_interfaces::msg::LpsSaJobMgrRespChannel` | JobMgr acknowledgements and command status. |
| `lps_sa_load_record_channel` | `LoadRecordOutput` | `job_mgr_interfaces::msg::LpsSaLoadRecordChannel` | Finalized load records, subtotals, timestamps, and weights. |
| `lps_sa_weigh_resp_channel` | `LpsSaWeighRespChannelOutput` | `cpm_common_interfaces::msg::LpsSaWeighRespChannel` | Weigh command results, status, and request identity. |
| `lps_sa_weigh_tx_channel` | `LpsSaWeighTxChannelOutput` | `cpm_common_interfaces::msg::LpsSaWeighTxChannel` | Weighing telemetry, payload/linkage data, sensor status, PIDs, and seal state. |
| `lps_sa_job_mgr_tx_channel` | `LpsSaJobMgrTxChannelOutput` | `job_mgr_interfaces::msg::LpsSaJobMgrTxChannel` | JobMgr state, active task information, and weights. |
| `lps_sa_job_mgr_debug_channel` | `LpsSaJobMgrDebugChannelOutput` | `job_mgr_interfaces::msg::LpsSaJobMgrDebugChannel` | Pass-tracker and JobMgr debug data. |
| `output_channel` | `OutputChannelOutput` | `job_mgr_interfaces::msg::OutputChannel` | Discrete output commands, including horn-on-store behavior. |
| `lps_sa_weigh_init_debug_channel` | `LpsSaWeighInitDebugChannelOutput` | `weigh_app_interfaces::msg::LpsSaWeighInitDebugChannel` | WeighApp initialization diagnostics. |
| `lps_sa_weigh_debug_channel` | `LpsSaWeighDebugChannelOutput` | `weigh_app_interfaces::msg::LpsSaWeighDebugChannel` | Weigh algorithm, WRW, and tip-off-assist debug data. |
| `lps_sa_nvm_cal_data_channel` | `LpsSaNvmCalDataChannelOutput` | `weigh_app_interfaces::msg::LpsSaNvmCalDataChannel` | Stored calibration parameters. |
| `lps_sa_nvm_cal_on_the_fly_data_channel` | `LpsSaNvmCalOnTheFlyDataChannelOutput` | `weigh_app_interfaces::msg::LpsSaNvmCalOnTheFlyDataChannel` | On-the-fly calibration metrics. |
| `cal_mgr_cmd_resp` | `CalMgrCmdRespOutput` | `weigh_app_interfaces::msg::CalMgrCmdResp` | Calibration command results for diagnostics. |
| `system_hardware_health_request` | `SystemHardwareHealthRequestOutput` | `weigh_app_interfaces::msg::SystemHardwareHealthRequest` | Hardware-health polling requests. |
| `ready_to_flash_status` | `ReadyToFlashStatusOutput` | `weigh_app_interfaces::msg::ReadyToFlashStatus` | WeighApp flash-readiness status. |
| `tipoff_model_test_points` | `TipoffModelTestPointsOutput` | `weigh_app_interfaces::msg::TipoffModelTestPoints` | Tip-off model diagnostic test points. |

## Conversion and Runtime

The bridge creates a ROS2 node and wrapper publishers/subscribers during initialization, binds its SCS interfaces, and runs at a configured 20 Hz task cycle. Each cycle services the ROS2 executor and drains queued input messages before forwarding them. Conversion helpers map fields between the SCS data structures and generated ROS2 types; for example, weigh requests preserve command, caller/request identity, scalar arguments, and argument-map values, while weigh telemetry conversion maps payload, sensor, PID, diagnostic, IMU, and legal-for-trade seal fields.

The bridge provides transport conversion only. It does not replace application algorithms or make unlisted channels ROS2-based.

## Main Files

- `apps/LpsSaJobMgrApp/` contains JobMgr ROS2 interface setup and channel call sites.
- `apps/LpsSaWeighApp/` contains WeighApp ROS2 interface setup and channel call sites.
- `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp` contains SCS/ROS2 setup, forwarding, and conversions.
- `apps/ScsToRos2Bridge/ScsToRos2Bridge.h` declares the bridge interfaces and conversion helpers.
- `config/ScsToRos2Bridge.rb` registers the bridge's SCS interfaces and task parameters.
- `prod/common/ros2wrapper/RosInputInterface.h` and `RosOutputInterface.h` provide the ROS2 input/output wrappers.
- `prod/common/interfaces/LpsSaWeighReqstChannel/DDSWeighAppInf.hpp` provides the DDS-backed helper for the Weigh request/response integration.