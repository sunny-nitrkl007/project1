/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaCda.cpp
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#include <cmath>

#include <chrono/tz.hpp>

#include <boost/filesystem.hpp>

#ifndef  _LPS_SA_WEIGHAPP_H_
#include "LpsSaWeighApp.h"
#include "ROS2Logger.hpp"
#endif

#ifndef __LPS_PRIVATE_H__
#include <LpsPrivate.h>
#endif

#include <lps_sea_defs.h>
#include <LpsCalPublic.h>

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
#define TO_INT16_PID(value) (std::max(-32736.f, std::min(32767.f, std::roundf(value))))

/*******************************************************************************
** -- Function Prototypes --
*******************************************************************************/
/*******************************************************************************
** -- Data Declarations --
*******************************************************************************/
/******************************************************************************
FUNCTION NAME:LpsSaScsChkForReqst
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaScsChkForReqst()
{
    cpm_common_interfaces::msg::LpsSaWeighReqstChannel request;

    /* Retrieve SCS channel data */
    while (LpsSaWeighScsReqstIn->get(request)) {
        switch (request.command.value) {
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::ZERO):
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::RESET_BEST_BUCKET_WEIGHT):
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::CAPTURE_CYLINDER_EXTENSION_REFERENCE):
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::CLEAR_REWEIGH_WARNING): {
            // These commands are handled later.
            // old type so convert field-by-field.
            request_.command = static_cast<LpsSaWeighReqstChannel::Command>(request.command.value);
            request_.appName = request.app_name;
            request_.appRequestId = request.app_request_id;
            request_.arg.b = request.arg_b;
            request_.arg.f1 = request.arg_f1;
            request_.arg.f2 = request.arg_f2;
            request_.arg.s = request.arg_s;
            request_.arg.u = request.arg_u;
            request_.arg.map.clear();
            for (const auto& fp : request.arg_map) {
                request_.arg.map.emplace_back(fp.first, fp.second);
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_WEIGH_RANGE): {
            setWeighRange(request.arg_f1, request.arg_f2);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_BUCKET_PAYLOAD_TARGET_WEIGHT): {
            cnfg_.bucketPayloadTargetWeight = request.arg_f1;
            cnfg_.setSaveNeeded();
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"BucketPayloadTargetWeight = %f", cnfg_.bucketPayloadTargetWeight);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_OVERLOAD_WARNING_ENABLE): {
            cnfg_.overloadWarningEnabled = request.arg_b;
            cnfg_.setSaveNeeded();
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"OverloadWarningEnabled = %d", cnfg_.overloadWarningEnabled);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_HYD_OIL_TEMP_ENABLE): {
            LpsSaScsSendReqstResponse(request, setHydOilTempEnableStatus(request.arg_b));
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_IMU_COMP_ENABLE): {
            LpsSaScsSendReqstResponse(request, setIMUCompEnableStatus(request.arg_b));
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_AUDIBLE_WEIGHT_ENABLE): {
            LpsSaScsSendReqstResponse(request, setAudibleWeightEnableStatus(request.arg_b));
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_LFT_SEALED_FLASH_ENABLE): {
            if (payloadCalNvmTbl_.legalForTradeInstalled) {
                LpsSaScsSendReqstResponse(request, setFlashEnableStatus(request.arg_b));
            }
            else
            {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to write flash enable status");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_CALIBRATION_WEIGHT): {
            float calibrationWeight = request.arg_f1;
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"Write calibration weight request received: %f", calibrationWeight);

            if (((payloadCalNvmTbl_.data.CalWeight != calibrationWeight) ||
                    ((payloadCalNvmTbl_.data.CalStatus & CAL_BKT_WT_MASK) != CAL_BKT_WT_MASK)) && (calibrationWeight > 0.0)) {
                RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"Calibration weight set: %f", calibrationWeight);

                // Update calibration weight.
                payloadCalNvmTbl_.data.CalWeight = calibrationWeight;
                sealTracker_.reportCalibrationWeight(payloadCalNvmTbl_.data.CalWeight);

                payloadCalNvmTbl_.data.CalStatus |= CAL_BKT_WT_MASK;

                // The advanced cal adjust table is tracked by the calCounter.
                payloadCalNvmTbl_.setAdvCalAdjust({{0.f, 0.f}, {calibrationWeight, calibrationWeight}});

                if (GetPayloadCalStatus()) {
                    ++payloadCalNvmTbl_.calCounter; // This is a new completed calibration.
                    sealTracker_.reportPayloadCalStatus(true, payloadCalNvmTbl_.calCounter);
                }

                // Zero Call Data without resetting the simple calibration truck history list.
                // TODO: us15073 - Reset SimpleCal truck history list on Cal Weight changes. (Jeff Budill)

                payloadCalNvmTbl_.data.ZeroWeight = 0.f;

                payloadCalNvmTbl_.data.CalAdjust = 0.f;
                sealTracker_.reportSpanAdjustFactor(payloadCalNvmTbl_.data.CalAdjust);

                payloadCalNvmTbl_.setSaveNeeded();

                updatedSimpleCalFactor = 0.f;
                sumOfAdjustedTruckWts = 0.f;
                sumOfZeroedTruckWts = 0.f;

                CalNVMReinitFlag = true;

                // Log the calibration results on successful calibration wt write
                logWeighCalResults();
            }

            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_MACHINE_PITCH_CAL_OFFSET): {
            setIMUPitchCalOffsetNVM(request.arg_f1);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_LFT_SEALED): {
            sealTracker_.seal(request.arg_b);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_LIFT_POSITION_SENSOR_ID): {
            sealTracker_.reportLiftPositionSensorId(request.arg_s);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_TILT_POSITION_SENSOR_ID): {
            sealTracker_.reportTiltPositionSensorId(request.arg_s);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_LIFT_HE_PRESSURE_SENSOR_ID): {
            sealTracker_.reportLiftHeadEndPressureSensorId(request.arg_s);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_LIFT_RE_PRESSURE_SENSOR_ID): {
            sealTracker_.reportLiftRodEndPressureSensorId(request.arg_s);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_HYDRAULIC_OIL_TEMP_SENSOR_ID): {
            sealTracker_.reportHydraulicOilTemperatureSensorId(request.arg_s);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_WORK_TOOL_ID): {
            sealTracker_.reportWorkToolId(request.arg_s);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_PAYLOAD_OUT_OF_CAL): {
            // make payload out of cal when AU2020 and NOT Legal for Trade, since we use calibration from impl
            setPayloadNotCalibrated();
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::NOTIFY_TICKET_NUMBER_WRITE): {
            sealTracker_.reportTicketNumberWrite(request.arg_u);
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::PUBLISH_SERVICE_HISTORY): {
            const std::string filePath(makeTempPath("ServiceHistory.json"));
            if (sealTracker_.publish(filePath)) {
                LpsSaScsSendReqstResponse(request, true, filePath);
               RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Service history published");
            }
            else {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish service history");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::PUBLISH_LIFT_SENSOR_CALIBRATION): {
            const std::string filePath(makeTempPath("LiftSensorCalibration.json"));
            if (liftCalNvmTbl_.publish(filePath)) {
                LpsSaScsSendReqstResponse(request, true, filePath);
               RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Lift sensor calibration published");
            }
            else {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish lift sensor calibration");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::PUBLISH_TILT_SENSOR_CALIBRATION): {
            const std::string filePath(makeTempPath("TiltSensorCalibration.json"));
            if (tiltCalNvmTbl_.publish(filePath)) {
                LpsSaScsSendReqstResponse(request, true, filePath);
               RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Tilt sensor calibration published");
            }
            else {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish tilt sensor calibration");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::PUBLISH_WEIGH_CALIBRATION): {
            const std::string filePath(makeTempPath("WeighCalibration.json"));
            if (payloadCalNvmTbl_.publish(filePath)) {
                LpsSaScsSendReqstResponse(request, true, filePath);
               RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Weigh calibration published");
            }
            else {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish weigh calibration");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::PUBLISH_WEIGH_CONFIGURATION): {
            const std::string filePath(makeTempPath("WeighConfiguration.json"));
            if (cnfg_.publish(filePath)) {
                LpsSaScsSendReqstResponse(request, true, filePath);
               RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Weigh configuration published");
            }
            else {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish weigh configuration");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::PUBLISH_RECENT_WEIGH_RESULTS): {
            const std::string filePath(makeTempPath("RecentWeighResults.json"));
            if (publishRecentWeighResults(filePath)) {
                LpsSaScsSendReqstResponse(request, true, filePath);
               RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Weigh results published");
            }
            else {
                LpsSaScsSendReqstResponse(request, false);
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish weigh results");
            }
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_REWEIGH_MAX_PITCH): {
            float reweighMaxPitch = request.arg_f1;
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"reweighMaxPitch = %f", reweighMaxPitch);
            cnfg_.reweighMaxPitch = reweighMaxPitch;
            sealTracker_.reportGenericConfigurationChange("MaxPitch:" + std::to_string(reweighMaxPitch));
            cnfg_.setSaveNeeded();
            CalNVMReinitFlag = TRUE;
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_REWEIGH_MIN_PITCH): {
            float reweighMinPitch = request.arg_f1;
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"reweighMinPitch = %f", reweighMinPitch);
            cnfg_.reweighMinPitch = reweighMinPitch;
            sealTracker_.reportGenericConfigurationChange("MinPitch:" + std::to_string(reweighMinPitch));
            cnfg_.setSaveNeeded();
            CalNVMReinitFlag = TRUE;
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_REWEIGH_MAX_ABS_ROLL): {
            float reweighMaxAbsRoll = request.arg_f1;
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"reweighMaxAbsRoll = %f", reweighMaxAbsRoll);
            cnfg_.reweighMaxAbsRoll = reweighMaxAbsRoll;
            sealTracker_.reportGenericConfigurationChange("MaxRoll:" + std::to_string(reweighMaxAbsRoll));
            cnfg_.setSaveNeeded();
            CalNVMReinitFlag = TRUE;
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_REWEIGH_MIN_LIFT_CYL_VEL): {
            float reweighMinLiftCylVel = request.arg_f1;
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"reweighMinLiftCylVel = %f", reweighMinLiftCylVel);
            cnfg_.reweighMinLiftCylVel = reweighMinLiftCylVel;
            sealTracker_.reportGenericConfigurationChange("MinLiftVel:" + std::to_string(reweighMinLiftCylVel));
            cnfg_.setSaveNeeded();
            CalNVMReinitFlag = TRUE;
            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::WRITE_ADVANCED_CALIBRATION_ADJUSTMENT): {
            RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"Write advanced calibration adjustment received.");

            // The advanced cal adjust table is tracked by the calCounter.
            {
                std::vector<std::pair<float, float>> argMapOld;
                for (const auto& fp : request.arg_map) {
                    argMapOld.emplace_back(fp.first, fp.second);
                }
                payloadCalNvmTbl_.setAdvCalAdjust(argMapOld);
            }

            if (GetPayloadCalStatus()) {
                ++payloadCalNvmTbl_.calCounter; // This is a new completed calibration.
                sealTracker_.reportPayloadCalStatus(true, payloadCalNvmTbl_.calCounter);
            }

            // Zero Call Data without resetting the simple calibration truck history list.
            // TODO: us15073 - Reset SimpleCal truck history list on Cal Weight changes. (Jeff Budill)

            payloadCalNvmTbl_.data.ZeroWeight = 0.f;

            payloadCalNvmTbl_.data.CalAdjust = 0.f;
            sealTracker_.reportSpanAdjustFactor(payloadCalNvmTbl_.data.CalAdjust);

            payloadCalNvmTbl_.setSaveNeeded();

            updatedSimpleCalFactor = 0.f;
            sumOfAdjustedTruckWts = 0.f;
            sumOfZeroedTruckWts = 0.f;

            CalNVMReinitFlag = true;

            // Log the calibration results on successful calibration wt write
            logWeighCalResults();

            LpsSaScsSendReqstResponse(request, true);
            return;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::RUN_TEST): {
            std::string fileName = boost::filesystem::path(request.arg_s).filename().string();
            if (!fileName.empty()) {
                auto pos = fileName.find_first_of('.');
                if (0 != pos) { // Can't start with '.'
                    if (std::string::npos == pos) {
                        // No dot
                        fileName += ".csv";
                    }
                    testFixture_.runTestPlan(tempRoot_ / "test" / fileName);
                }
            }
            break;
        }
        case (cpm_common_interfaces::msg::WeighReqstChannelCommand::RECORD_TEST): {
            if (request.arg_u > 0) {
                testFixture_.recordTestPlan(tempRoot_ / "test" / "record.csv", std::chrono::seconds(request.arg_u));
            }
            break;
        }
        default: {
           RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Unsupported request command.");
            break;
        }
        }
    }

    return;
}

/******************************************************************************
FUNCTION NAME:LpsSaScsSendReqstResponse
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
bool LpsSaWeighApp::LpsSaScsSendReqstResponse(LpsSaWeighReqstChannel::Command command, bool success)
{
    if (command != request_.command) {
       RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Request and response command mismatch.");
        return false;
    }

    // request_ is the old raw SCS type
    cpm_common_interfaces::msg::LpsSaWeighReqstChannel newRequest;
    newRequest.app_name = request_.appName;
    newRequest.app_request_id = request_.appRequestId;
    newRequest.command.value = static_cast<uint8_t>(request_.command);

    bool rVal = LpsSaScsSendReqstResponse(newRequest, success);

    // Clear out the request since it has been handled.
    request_.reInit();

    return rVal;
}

bool LpsSaWeighApp::LpsSaScsSendReqstResponse(const cpm_common_interfaces::msg::LpsSaWeighReqstChannel& request, bool success, const std::string& arg1) {
    // Build the response
    cpm_common_interfaces::msg::LpsSaWeighRespChannel response; // Default timepoint is now
    response.app_name = request.app_name;
    response.app_request_id = request.app_request_id;
    response.command = request.command;
    response.success = success;
    response.arg1 = arg1;

    response.time_point_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();

     /* send response ROS2 topic */
    if (LpsSaWeighScsRespOut_ROS2) {
        if (LpsSaWeighScsRespOut_ROS2->publish(response)) {
           RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"[ROS2] Published response, command=%d, success=%d", response.command.value, success);
            return true;
        } else {
           RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"[ROS2] Failed to publish response, command=%d, success=%d", response.command.value, success);
        }
    }

   RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Failed to publish response, command=%d, success=%d", response.command.value , success);
    return false;
}

/******************************************************************************
FUNCTION NAME: AisJhmDataServerTxRead
DESCRIPTION:            
PARAMETER DESCRIPTION:                        
RETURN VALUE:             
*******************************************************************************/
void LpsSaWeighApp::AisJhmDataServerTxRead()
{

 cpm_common_interfaces::msg::AisJhm2TxChannel AisJhm2TxIn;
    while (AisJhm2TxRosIn_->get(AisJhm2TxIn)) {
        if (AisJhm2TxIn.simplecal_data.new_data_flag) {
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"### AIS Adj wt = %f", AisJhm2TxIn.simplecal_data.adjtruckweight);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"### AIS Zeroed wt = %f", AisJhm2TxIn.simplecal_data.zeroed_truck_wt);

            sumOfAdjustedTruckWts += AisJhm2TxIn.simplecal_data.adjtruckweight;
            sumOfZeroedTruckWts += AisJhm2TxIn.simplecal_data.zeroed_truck_wt;

            if (sumOfZeroedTruckWts > 0.0f) {
                updatedSimpleCalFactor = sumOfAdjustedTruckWts/sumOfZeroedTruckWts;
                RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"Updated simple cal factor = %f", updatedSimpleCalFactor);
            }
        }

        if (AisJhm2TxIn.tipoff_weight_adjust_data.new_data_flag) {
            auto tipOffWeight1 = AisJhm2TxIn.tipoff_weight_adjust_data.tip_off_weight1;
            auto weighRangeWeight1 = AisJhm2TxIn.tipoff_weight_adjust_data.weigh_range_weight1;
            auto tipOffWeight2 = AisJhm2TxIn.tipoff_weight_adjust_data.tip_off_weight2;
            auto weighRangeWeight2 = AisJhm2TxIn.tipoff_weight_adjust_data.weigh_range_weight2;

            // If weight 1 is not given, use weight 2 twice
            if (!std::isfinite(tipOffWeight1) ||
                    !std::isfinite(weighRangeWeight1)) {
                tipOffWeight1 = tipOffWeight2;
                weighRangeWeight1 = weighRangeWeight2;
            }

            // If weight 2 is not given, use weight 1 twice
            if (!std::isfinite(tipOffWeight2) ||
                    !std::isfinite(weighRangeWeight2)) {
                tipOffWeight2 = tipOffWeight1;
                weighRangeWeight2 = weighRangeWeight1;
            }

           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"tipOffWeight1: %f", tipOffWeight1);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"weighRangeWeight1: %f", weighRangeWeight1);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"tipOffWeight2: %f", tipOffWeight2);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"weighRangeWeight2: %f", weighRangeWeight2);

            auto calAdjust = LpsSaWeighInfoTbl.TipoffInputs.simple_cal_factor;
            auto zeroWeight = LpsSaWeighInfoTbl.TipoffInputs.zero_offset;
            auto anchorFactor = cnfg_.toaAnchoredFactor;
            auto anchorZero = cnfg_.toaAnchoredZeroOffset;

           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"calAdjust: %f", calAdjust);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"zeroWeight: %f", zeroWeight);

           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"anchorFactor: %f", anchorFactor);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"anchorZero: %f", anchorZero);

            // Undo existing simple cal
            float tipOffWeight1NoSc = tipOffWeight1 / calAdjust + zeroWeight;
            float weighRangeWeight1NoSc = weighRangeWeight1 / calAdjust + zeroWeight;
            float tipOffWeight2NoSc = tipOffWeight2 / calAdjust + zeroWeight;
            float weighRangeWeight2NoSc = weighRangeWeight2 / calAdjust + zeroWeight;

            // Undo existing anchoring
            float tipOffWeight1NoAnchor = tipOffWeight1NoSc / anchorFactor + anchorZero;
            float tipOffWeight2NoAnchor = tipOffWeight2NoSc / anchorFactor + anchorZero;

            float newAnchorFactor, newAnchorZero;

            // Calculate new anchoring values
            if (std::abs(tipOffWeight1NoAnchor - tipOffWeight2NoAnchor) >= (machineProperties.ratedPayload / 3.f)) {
                // The two different weights given are far enough apart to use a line.
                newAnchorFactor = (weighRangeWeight1NoSc - weighRangeWeight2NoSc) / (tipOffWeight1NoAnchor - tipOffWeight2NoAnchor);
                newAnchorZero = tipOffWeight2NoAnchor - (weighRangeWeight2NoSc / newAnchorFactor);
            }
            else {
                // The two different weights are too close together, just use an offset.
                newAnchorFactor = 1.f;
                newAnchorZero = ((tipOffWeight2NoAnchor + tipOffWeight1NoAnchor) - (weighRangeWeight2NoSc + weighRangeWeight1NoSc)) / 2.f;
            }

           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"newAnchorFactor: %f", newAnchorFactor);
           RCLCPP_DEBUG(ROS2Logger::Instance().GetLogger(),"newAnchorZero:%f", newAnchorZero);

            // check validity of new anchor values: new anchor values are not finite values or payload is not calibrated
            if (!std::isfinite(newAnchorFactor) ||
                    !std::isfinite(newAnchorZero) ||
                    !GetPayloadCalStatus()) {
                // set anchor status to rejected and we will keep old anchor values
                LpsSaWeighInfoTbl.ToaAnchorStatus =
                        LpsSaWeighTxChannelStorage::ToaAnchorStatus_t::REJECTED;
            }
            else {
                // publish accepted and update anchor values
                cnfg_.toaAnchoredFactor = newAnchorFactor;
                cnfg_.toaAnchoredZeroOffset = newAnchorZero;
                cnfg_.setSaveNeeded();

                // unlatch the tipoff weight which it might be holding with old anchor values
                LpsSaWeighInfoTbl.TipoffInputs.unlatch_trigger = true;

                // set anchor status to accepted
                LpsSaWeighInfoTbl.ToaAnchorStatus =
                        LpsSaWeighTxChannelStorage::ToaAnchorStatus_t::ACCEPTED;
            }
        }
        else if (AisJhm2TxIn.tipoff_weight_adjust_data.reset) {
            resetToaAnchorValues();
        }
    }

    return;
}

/******************************************************************************
FUNCTION NAME: LpsSaSEAStatus
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaSEAStatus( )
{
    /*TODO: We are initializing the status of the SEA to installed/enabled,
     * we should probably disable the SEA if we do not receive a SEA object
     * in the first x minutes */

    cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel txData;
    while (AutonomyConditionDiagnosticsTxRosIn_->get(txData)) {
        for (const auto & element : txData.sea_list) {
            if (element.reason_code == LPS_SEA_REASON_CODE_149) {
                LpsSaWeighInfoTbl.SEALevel1EssentialsInstalled = AutonomyConditionDiagnosticsTxInterfaceStorage::checkSEAEnableStatus(element.status);
            }
            else if (element.reason_code == LPS_SEA_LFT_REASON_CODE_312) {
                bool installed = AutonomyConditionDiagnosticsTxInterfaceStorage::checkSEAEnableStatus(element.status);

                // Update if a change is detected
                if (installed != payloadCalNvmTbl_.legalForTradeInstalled) {
                    payloadCalNvmTbl_.legalForTradeInstalled = installed;

                    payloadCalNvmTbl_.setSaveNeeded();

                    CalNVMReinitFlag = true;

                    if (installed) {
                       RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Legal For Trade SEA is Installed & Enabled");
                    }
                }

                // Update the seal tracker
                sealTracker_.reportLegalForTradeEnableStatus(installed);
            }
        }
    }

    if (LpsSaWeighInfoTbl.SEALevel1EssentialsInstalled) {
        LpsSaWeighInfoTbl.DiagState[ACDDiagPopUp::PAYLOAD_SYSTEM_NOT_INSTALLED] = false;
    }
    else {
        LpsSaWeighInfoTbl.DiagState[ACDDiagPopUp::PAYLOAD_SYSTEM_NOT_INSTALLED] = true;
    }
}

void LpsSaWeighApp::LpsSaBattVoltageRead( )
{
    /* send a request for SystemHardwareHealth at configured period */
    if (SystemHardwareHealthRequestRosOut_) {
        weigh_app_interfaces::msg::SystemHardwareHealthRequest request;
        SystemHardwareHealthRequestRosOut_->publish(request);
    }

    weigh_app_interfaces::msg::SystemHardwareHealthStorage rxData;
    while (SystemHardwareHealthRosIn_ && SystemHardwareHealthRosIn_->get(rxData)) {
        auto voltage = rxData.battery_voltage;

        // Battery Low condition
        if (voltage > 32) {
            if (!LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_HIGH]) {
                setAutonomyCondition(BatteryHigh("Battery High"));
                LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_HIGH] = true;
            }            
        }
        else if (LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_HIGH]) {
            clearAutonomyCondition<BatteryHigh>();
            LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_HIGH] = false;
        }  

        // Battery Low condition
        if (voltage < 9) {
            if (!LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_LOW]) {
                setAutonomyCondition(BatteryLow("Battery Low"));
                LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_LOW] = true;
            }            
        }
        else if (LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_LOW]) {
            clearAutonomyCondition<BatteryLow>();
            LpsSaWeighInfoTbl.EventState[ACDEventPopUp::BATTERY_LOW] = false;
        } 
    }
}


/******************************************************************************
FUNCTION NAME:LpsSaJobMgrScsRx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaWeighingScsRx( )
{
    /*Read the requests from JM App*/
    LpsSaScsChkForReqst();

    /*Read the param from JM*/
    LpsJobMgrTxRead();

    /* Read simple cal params from AisJhmDataServer. */
    AisJhmDataServerTxRead();

    /* Read Payload SEA status */
    LpsSaSEAStatus();

    /* Read params from Machine Interface */
    LpsSaBmiRead();

    /* Read and process battery voltage */
    LpsSaBattVoltageRead();

    // Make sure we are printing in the units that are defined by the display settings
    if (nullptr != displayStateInput_) {
        cpm_common_interfaces::msg::LpsSaUIDisplayStateInterface displayState;
        while (displayStateInput_->get(displayState)) {
            const auto& state = displayState.state;
            LpsSaWeighInfoTbl.inVerificationMode = state.in_verification_mode;
            LpsSaWeighInfoTbl.weightUnits = static_cast<LpsCommonWeightUnits>(state.settings.weight_units);
            LpsSaWeighInfoTbl.weightInterval = state.weight_interval;
            LpsSaWeighInfoTbl.weightCapacity = state.weight_capacity;
            if (!LpsSaWeighInfoTbl.inVerificationMode) {
                // Only report changes in weight interval if not in verification node.
                sealTracker_.reportWeightInterval(LpsSaWeighInfoTbl.weightInterval, state.weight_decimal_precision, LpsSaWeighInfoTbl.weightUnits);
            }
        }
    }

    // Report ticket retention period to seal tracker.
    if (nullptr != printerCnfgInput_) {
        weigh_app_interfaces::msg::LpsSaTotalsPrinterCnfg printerCnfg;
        while (printerCnfgInput_->get(printerCnfg)) {
            sealTracker_.reportTicketRetentionPeriod(printerCnfg.truck_ticket.retention_period);
        }
    }

    /* Receive local time offset and override the local time offset in chrono/print.hpp */
    if (nullptr != shmClockInput_) {
        cpm_common_interfaces::msg::ShmClockInput shmClockRos;
        while (shmClockInput_->get(shmClockRos)) {
            ShmClock shmClock;
            shmClock.set_SHM(shmClockRos.shm_sec);
            shmClock.set_UTC_offset(shmClockRos.utc_offset_min);
            shmClock.set_TZ(shmClockRos.tzone_info.data(), shmClockRos.tzone_info.size());
            int32_t offset = shmClock.get_UTC_offset();
            tzone_tx_comm_struct tzone;
            if (tes_common_ais::get_tz_struct(tzone, shmClock)) {
                if ((tzInfo_.offset != offset) || (tzInfo_.index != tzone.tzone_id)) {
                    std::string tzStr = tes_common_ais::makeTZString(tzone);
                    if (tes_common_ais::setTZString(tzStr)) {
                       RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Set TZ environment variable to '%s'.", tzStr.c_str());
                        tes_common_ais::clearLocalTimeOffsetOverride();
                    }
                    else {
                       RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Could not set TZ environment variable to '%s'.", tzStr.c_str());
                        tes_common_ais::setLocalTimeOffsetOverride(std::chrono::minutes(offset));
                    }
                    tzInfo_.offset = offset;
                    tzInfo_.index = tzone.tzone_id;
                }
            }
            else {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Could not get tzone_tx_comm_struct");
            }

            serviceHourMeter_ = shmClockRos.shm_sec;
        }
    }
}

/******************************************************************************
FUNCTION NAME: LpsSaScsSendZeroRqst
DESCRIPTION:
PARAMETER DESCRIPTION: Publishes a zero request on the JobMgr Reqst channel
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaScsSendZeroRqst()
{
    bool scsReqstRet=false;

    if (LpsSaJobMgrReqstRosOut_) {
        cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel req;
        req.command.value = cpm_common_interfaces::msg::JobMgrReqstChannelCommand::ZERO;
        scsReqstRet = LpsSaJobMgrReqstRosOut_->publish(req);
    }

    if (!scsReqstRet) {
       RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"LpsSaScsSendZeroRqst Fail to Send Command::ZERO");
    }
}
/******************************************************************************
FUNCTION NAME: LpsSaWeighingScsTx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE: true if successful, else false
*******************************************************************************/
bool LpsSaWeighApp::LpsSaWeighingScsTx()
{
    bool scsCmdRet = false;
    if (nullptr != LpsSaWeighScsTxOut_ROS2) {
        cpm_common_interfaces::msg::LpsSaWeighTxChannel txOut;

        txOut.dig_stat = LpsSaWeighInfoTbl.DigStat;
        txOut.time_point_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                std::chrono::steady_clock::now().time_since_epoch()).count();

        ACDWeighStatus::type prodMeasureWeighStatusBits;

        if (GetPayloadMonSysCalStatus()) {
            txOut.cal_stat = LPS_WEIGH_SYSTEM_CALIBRATED;
        }
        else {
            txOut.cal_stat = LPS_WEIGH_SYSTEM_UNCALIBRATED;
        }

        txOut.dump_stat = LpsSaWeighInfoTbl.DumpStat;
        txOut.best_bkt_wt_in_tonnes = LpsSaWeighInfoTbl.BestBktWtInTonnes;
        txOut.warmup_lifts_required = LpsRemainingWarmupLiftsRequired();
        txOut.payload_calc_meth = LpsSaWeighInfoTbl.PayloadCalcMeth;
        txOut.bkt_wt_latched_flag = LpsSaWeighInfoTbl.BestBktWtLatched;
        txOut.latch_conditions_met = LpsSaWeighInfoTbl.LatchConditionsOK;
        txOut.zero_available = LpsWeighIsZeroWeightAvailable();

        txOut.payload.payload_ratio_raw = LpsSaWeighInfoTbl.Payload.payloadRatioRaw;
        txOut.payload.payload_ratio = LpsSaWeighInfoTbl.Payload.payloadRatio;
        txOut.payload.payload_ratio_status = static_cast<int32_t>(LpsSaWeighInfoTbl.Payload.payloadRatioStatus);

        {
            LpsSaLftSealStatus_t sealStatus = sealTracker_.getSealStatus();
            txOut.lft_seal_status.sealed = sealStatus.sealed;
            txOut.lft_seal_status.seal_time_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
                    sealStatus.sealTime.time_since_epoch()).count();
            txOut.lft_seal_status.seal_id = sealStatus.sealId;
        }

        txOut.flash_enabled = cnfg_.flashEnabled;

        { // Sensor & Work Tool Identifiers
            const auto& seal = sealTracker_.getSeal();
            txOut.lift_position_sensor_id = seal.liftPositionSensorId;
            txOut.tilt_position_sensor_id = seal.tiltPositionSensorId;
            txOut.lift_head_end_pressure_sensor_id = seal.liftHeadEndPressureSensorId;
            txOut.lift_rod_end_pressure_sensor_id = seal.liftRodEndPressureSensorId;
            txOut.hydraulic_oil_temperature_sensor_id = seal.hydraulicOilTemperatureSensorId;
            txOut.imu_sensor_id = seal.imuSerialNumber;
            txOut.work_tool_id = seal.workToolId;
            txOut.implement_serial_num = seal.inputModuleEcmSerialNumber;
        }

        txOut.lift_position.angle = LpsSaWeighInfoTbl.LiftPosition.angle;
        txOut.lift_position.percent_angle = LpsSaWeighInfoTbl.LiftPosition.percentAngle;
        txOut.lift_position.cylinder_length = LpsSaWeighInfoTbl.LiftPosition.cylinderLength;
        txOut.lift_position.percent_cylinder_length = LpsSaWeighInfoTbl.LiftPosition.percentCylinderLength;
        txOut.lift_position.cylinder_extension = LpsSaWeighInfoTbl.LiftPosition.cylinderExtension;
        txOut.lift_position.status = static_cast<int32_t>(LpsSaWeighInfoTbl.LiftPosition.status);

        txOut.lift_cyl_vel.stat = static_cast<int32_t>(LpsSaWeighInfoTbl.LiftCylVel.Stat);
        txOut.lift_cyl_vel.val = LpsSaWeighInfoTbl.LiftCylVel.Val;

        txOut.tilt_position.angle = LpsSaWeighInfoTbl.TiltPosition.angle;
        txOut.tilt_position.percent_angle = LpsSaWeighInfoTbl.TiltPosition.percentAngle;
        txOut.tilt_position.cylinder_length = LpsSaWeighInfoTbl.TiltPosition.cylinderLength;
        txOut.tilt_position.percent_cylinder_length = LpsSaWeighInfoTbl.TiltPosition.percentCylinderLength;
        txOut.tilt_position.cylinder_extension = LpsSaWeighInfoTbl.TiltPosition.cylinderExtension;
        txOut.tilt_position.bucket_angle = LpsSaWeighInfoTbl.TiltPosition.bucketAngle;
        txOut.tilt_position.status = static_cast<int32_t>(LpsSaWeighInfoTbl.TiltPosition.status);

        txOut.weigh_range.weigh_range_bottom = cnfg_.weighRangeStart;
        txOut.weigh_range.weigh_range_size = cnfg_.weighRangeSize;
        txOut.pid_data.overload_warning_enabled = cnfg_.overloadWarningEnabled;
        txOut.can11_message_timeout_flag = LpsSaWeighInfoTbl.CAN11MessageTimeoutFlag;
        txOut.toa_anchored_zero_offset = cnfg_.toaAnchoredZeroOffset;
        txOut.toa_anchored_factor = cnfg_.toaAnchoredFactor;
        txOut.toa_anchor_status = static_cast<uint8_t>(LpsSaWeighInfoTbl.ToaAnchorStatus);

        if (chassisImu_.imuOk) {
            auto calibratedLinAccelVector = chassisImu_.imu.calibratedLinAccelVector();
            txOut.pid_data.machine_rear_lateral_acceleration = TO_INT16_PID(calibratedLinAccelVector.y() * 100.f);
            txOut.pid_data.machine_rear_longitudinal_acceleration = TO_INT16_PID(calibratedLinAccelVector.x() * 100.f);
            txOut.pid_data.machine_rear_vertical_acceleration = TO_INT16_PID(calibratedLinAccelVector.z() * 100.f);

            txOut.pid_data.machine_pitch = TO_INT16_PID(chassisImu_.imu.pitchDegrees() * 10.f);
            txOut.pid_data.machine_slope = TO_INT16_PID(chassisImu_.imu.pitchGrade() * 10.f);

            /*
             * The PID definitions for roll are really bad.
             * What they call side slope is not really side slope of the ground, but roll
             * of the machine about the machine x-axis, converted to grade units.
             * This is different than the slope of the ground from the "world" reference frame where the x-axis
             * is perpendicular to the gravity vector instead of in the direction of machine motion.
             */
            txOut.pid_data.machine_rear_roll = TO_INT16_PID(chassisImu_.imu.rollDegrees() * 100.f);
            txOut.pid_data.machine_rear_side_slope = TO_INT16_PID(chassisImu_.imu.rollGrade() * 10.f);
            txOut.pid_data.machine_roll = txOut.pid_data.machine_rear_roll;
            txOut.pid_data.machine_side_slope = TO_INT16_PID(-txOut.pid_data.machine_rear_side_slope);
        }
        else {
            txOut.pid_data.machine_rear_lateral_acceleration = UNKNOWN2S + FMICNM; /* dsi */
            txOut.pid_data.machine_rear_longitudinal_acceleration = UNKNOWN2S + FMICNM; /* dsi */
            txOut.pid_data.machine_rear_vertical_acceleration = UNKNOWN2S + FMICNM; /* dsi */

            txOut.pid_data.machine_pitch = UNKNOWN2S + FMICNM;
            txOut.pid_data.machine_slope = UNKNOWN2S + FMICNM;
            txOut.pid_data.machine_rear_roll = UNKNOWN2S + FMICNM;
            txOut.pid_data.machine_rear_side_slope = UNKNOWN2S + FMICNM;
            txOut.pid_data.machine_roll = UNKNOWN2S + FMICNM;
            txOut.pid_data.machine_side_slope = UNKNOWN2S + FMICNM;
        }

        txOut.pid_data.tipoff_pitch_cal_offset = cnfg_.tipoffPitchCalOffset;
        txOut.pid_data.hyd_oil_temp_enabled = cnfg_.hydOilTempEnabled;
        txOut.pid_data.audible_weight_enabled = cnfg_.audibleWeightEnabled;

        prodMeasureWeighStatusBits[ACDWeighStatus::LOWER_STALL] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_LOWER_STALL];
        prodMeasureWeighStatusBits[ACDWeighStatus::RAISE_STALL] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_RAISE_STALL];
        prodMeasureWeighStatusBits[ACDWeighStatus::INSUFFICIENT_DATA] = false;
        prodMeasureWeighStatusBits[ACDWeighStatus::REWEIGH_PRESSURE_CHANGING] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_PRESSURE_CHANGING];
        prodMeasureWeighStatusBits[ACDWeighStatus::REWEIGH_INCONSISTENT] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_INCONSISTENT];
        prodMeasureWeighStatusBits[ACDWeighStatus::REWEIGH_SPEED_CHANGING] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_SPEED_CHANGING];
        prodMeasureWeighStatusBits[ACDWeighStatus::REWEIGH_NOT_RACKED_EXCESSIVE_PITCH] =
                LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_NOT_RACKED] ||
                LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_EXCESSIVE_PITCH];
        prodMeasureWeighStatusBits[ACDWeighStatus::REWEIGH_STOPPED_IN_RANGE] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_STOPPED_IN_RANGE];
        prodMeasureWeighStatusBits[ACDWeighStatus::REWEIGH_LIFT_TOO_SLOW] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_LIFT_TOO_SLOW];
        prodMeasureWeighStatusBits[ACDWeighStatus::INSUFFICIENT_DATA] = LpsSaWeighInfoTbl.InfoState[ACDInfoPopUp::PAYLOAD_REWEIGH_WARMUP_LIFT];
        /* send audible tone command */
        txOut.pid_data.audible_weight_command = getAudibleCommand();

        txOut.pid_data.pload_sys_cal_wt_entry_req_stat = static_cast<uint16_t>(WeighPidTbl.PloadSysCalWtEntryReqStat);

        if (CAL_ENTRY_REQUIRED == WeighPidTbl.PloadSysCalWtEntryReqStat) {
            txOut.pid_data.last_pload_wt = cnfg_.lastSuggestedCalWeight;
        }
        else {
            txOut.pid_data.last_pload_wt = -1.f;
        }

        txOut.cal_wt = payloadCalNvmTbl_.data.CalWeight;
        txOut.indicator = static_cast<int32_t>(LpsSaWeighInfoTbl.Indicator);
        txOut.lift_stalled = LpsWrk.LpsStallDetect.liftStalled;
        txOut.lift_valve_command.stat = static_cast<int32_t>(LpsSaWeighInfoTbl.LiftValveCommand.Stat);
        txOut.lift_valve_command.val = LpsSaWeighInfoTbl.LiftValveCommand.Val;
        txOut.tilt_valve_command.stat = static_cast<int32_t>(LpsSaWeighInfoTbl.TiltValveCommand.Stat);
        txOut.tilt_valve_command.val = LpsSaWeighInfoTbl.TiltValveCommand.Val;
        txOut.zero_weight = payloadCalNvmTbl_.data.ZeroWeight;
        txOut.simple_cal_adjust = payloadCalNvmTbl_.data.CalAdjust;

        // EventState/DiagState/InfoState/ProdMeasureWeighStatus are std::bitset<N>
        auto eventStateBits = LpsSaWeighInfoTbl.EventState;
        auto diagStateBits = LpsSaWeighInfoTbl.DiagState;
        auto infoStateBits = LpsSaWeighInfoTbl.InfoState;

        if (diagStateBits.none()) {
            // No diagnostics, check battery voltage events and imu w/lft
            if (STATUS_GOOD != LpsChkInputStat()) {
                txOut.pid_data.bkt_payload_data = cpm_common_interfaces::msg::WeighPidData::BKT_PAYLOAD_NOT_AVAILABLE;
                txOut.show_exclamation_point = true;
                txOut.bucket_fully_racked = true;
                txOut.excessive_pitch = false;
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Input status not good, suppressing payload availability.");
            }
            else {
                txOut.show_exclamation_point = false;
                txOut.bucket_fully_racked = LpsWeighFullRackDetectStrict();
                txOut.excessive_pitch = LpsGetExcessivePitchStatus();
                txOut.pid_data.bkt_payload_data = cpm_common_interfaces::msg::WeighPidData::BKT_PAYLOAD_AVAILABLE;
            }
        }
        else {
            // We have at least one diagnostic.
           RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostics present, suppressing payload availability. DiagState: %s",diagStateBits.to_string().c_str());
            if (diagStateBits[ACDDiagPopUp::HYDRAULIC_OIL_TEMP_BAD]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: HYDRAULIC_OIL_TEMP_BAD");
            }
            if (diagStateBits[ACDDiagPopUp::LIFT_HE_FREQ_ABNORMAL] ||
                diagStateBits[ACDDiagPopUp::LIFT_HE_VOLTAGE_ABOVE_NORMAL] ||
                diagStateBits[ACDDiagPopUp::LIFT_HE_VOLTAGE_BELOW_NORMAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: LIFT_HE_BAD");
            }
            if (diagStateBits[ACDDiagPopUp::LIFT_RE_FREQ_ABNORMAL] ||
                diagStateBits[ACDDiagPopUp::LIFT_RE_VOLTAGE_ABOVE_NORMAL] ||
                diagStateBits[ACDDiagPopUp::LIFT_RE_VOLTAGE_BELOW_NORMAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: LIFT_RE_BAD");
            }
            if (diagStateBits[ACDDiagPopUp::TILT_HE_FREQ_ABNORMAL] ||
                diagStateBits[ACDDiagPopUp::TILT_HE_VOLTAGE_ABOVE_NORMAL] ||
                diagStateBits[ACDDiagPopUp::TILT_HE_VOLTAGE_BELOW_NORMAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: TILT_HE_BAD");
            }
            if (diagStateBits[ACDDiagPopUp::TILT_RE_FREQ_ABNORMAL] ||
                diagStateBits[ACDDiagPopUp::TILT_RE_VOLTAGE_ABOVE_NORMAL] ||
                diagStateBits[ACDDiagPopUp::TILT_RE_VOLTAGE_BELOW_NORMAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: TILT_RE_BAD");
            }
            if (diagStateBits[ACDDiagPopUp::MACHINE_MODEL_NOT_SET]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: MACHINE_MODEL_NOT_SET");
            }
            if (diagStateBits[ACDDiagPopUp::PAYLOAD_SYSTEM_NOT_INSTALLED]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: PAYLOAD_SYSTEM_NOT_INSTALLED");
            }
            if (diagStateBits[ACDDiagPopUp::PAYLOAD_SYSTEM_OUT_OF_CAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: PAYLOAD_SYSTEM_OUT_OF_CAL");
            }
            if (diagStateBits[ACDDiagPopUp::PAYLOAD_SYSTEM_OUT_OF_CAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: PAYLOAD_SYSTEM_OUT_OF_CAL");
            }
            if (diagStateBits[ACDDiagPopUp::LIFT_LINK_OUT_OF_CAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: LIFT_LINK_OUT_OF_CAL");
            }
            if (diagStateBits[ACDDiagPopUp::TILT_LINK_OUT_OF_CAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: TILT_LINK_OUT_OF_CAL");
            }
            if (diagStateBits[ACDDiagPopUp::LIFT_LINK_FREQ_ABNORMAL] ||
                diagStateBits[ACDDiagPopUp::LIFT_LINK_VOLTAGE_ABOVE_NORMAL] ||
                diagStateBits[ACDDiagPopUp::LIFT_LINK_VOLTAGE_BELOW_NORMAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: LIFT_LINK_BAD");
            }
            if (diagStateBits[ACDDiagPopUp::TILT_LINK_FREQ_ABNORMAL] ||
                diagStateBits[ACDDiagPopUp::TILT_LINK_VOLTAGE_ABOVE_NORMAL] ||
                diagStateBits[ACDDiagPopUp::TILT_LINK_VOLTAGE_BELOW_NORMAL]) {
               RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"Diagnostic: TILT_LINK_BAD");
            }

            txOut.show_exclamation_point = true;
            txOut.bucket_fully_racked = true;
            txOut.excessive_pitch = false;

            // Don't show warm-up required if there is any diagnostic
            txOut.warmup_lifts_required = 0;

            if (diagStateBits[ACDDiagPopUp::PAYLOAD_SYSTEM_NOT_INSTALLED]) {
                // Suppress all other info/event/diag if SEA is not installed/enabled
                diagStateBits.reset();
                infoStateBits.reset();
                eventStateBits.reset();
                diagStateBits[ACDDiagPopUp::PAYLOAD_SYSTEM_NOT_INSTALLED] = true;

                txOut.pid_data.bkt_payload_data = cpm_common_interfaces::msg::WeighPidData::BKT_PAYLOAD_NOT_INSTALLED;

                // Don't say calibration weight entry is required if not installed.
                txOut.pid_data.pload_sys_cal_wt_entry_req_stat = CAL_ENTRY_NOT_REQUIRED;
            }
            else {
                // We are installed with at least one diagnostic.
                txOut.pid_data.bkt_payload_data = cpm_common_interfaces::msg::WeighPidData::BKT_PAYLOAD_NOT_AVAILABLE;
            }
        }

        /* engine speed to auto-cals */
        txOut.engine_speed_rpm = LpsSaWeighInfoTbl.EngineSpeedRPM;

        /*Production Measurement Sensor Status*/
        txOut.pid_data.prod_measure_sensor_status.lift_link_dc = WeighPidTbl.LiftLinkageSensorDc; // Lift Linkage Position Sensor Duty Cycle

        if (LpsSaWeighInfoTbl.LiftPosition.status == LPS_STATUS_BAD) {
            txOut.pid_data.prod_measure_sensor_status.lift_cyl_pos = UNKNOWN2U + FMICNM;
        }
        else {
            txOut.pid_data.prod_measure_sensor_status.lift_cyl_pos = weighUpdtTbl.LiftCylLengthNorm.Val;/*Lift Cylinder Position*/
        }

        if (weighUpdtTbl.LiftCylHePres.Stat == LPS_STATUS_BAD) {
            txOut.pid_data.prod_measure_sensor_status.lift_cyl_he_pres = UNKNOWN2U + FMICNM;
        }
        else {
            txOut.pid_data.prod_measure_sensor_status.lift_cyl_he_pres = weighUpdtTbl.LiftCylHePres.Val;/*Lift Cylinder Head End Pressure*/
        }

        if (weighUpdtTbl.LiftCylRePres.Stat == LPS_STATUS_BAD) {
            txOut.pid_data.prod_measure_sensor_status.lift_cyl_re_pres = UNKNOWN2U + FMICNM;
        }
        else {
            txOut.pid_data.prod_measure_sensor_status.lift_cyl_re_pres = weighUpdtTbl.LiftCylRePres.Val;/*Lift Cylinder Rod End Pressure*/
        }

        txOut.pid_data.prod_measure_sensor_status.tilt_sensor_config = (linkage_table_cnfg.tiltSensorType == TILT_SENSOR_TYPE_ROTARY) ?
            cpm_common_interfaces::msg::ProdMeasureSensorStatus::TILT_SENSOR_ROTARY_POSITION : cpm_common_interfaces::msg::ProdMeasureSensorStatus::TILT_SENSOR_IN_CYLINDER_POSITION;

        if (LpsSaWeighInfoTbl.TiltCylHePres.Stat == LPS_STATUS_BAD) {
            txOut.pid_data.prod_measure_sensor_status.tilt_cyl_he_pres = UNKNOWN2U + FMICNM;
        }
        else {
            txOut.pid_data.prod_measure_sensor_status.tilt_cyl_he_pres = LpsSaWeighInfoTbl.TiltCylHePres.Val;/*Tilt Cylinder Head End Pressure*/
        }

        if (LpsSaWeighInfoTbl.TiltCylRePres.Stat == LPS_STATUS_BAD) {
            txOut.pid_data.prod_measure_sensor_status.tilt_cyl_re_pres = UNKNOWN2U + FMICNM;
        }
        else {
            txOut.pid_data.prod_measure_sensor_status.tilt_cyl_re_pres = LpsSaWeighInfoTbl.TiltCylRePres.Val;/*Tilt Cylinder Rob End Pressure*/
        }

        txOut.pid_data.prod_measure_sensor_status.tilt_link_dc = WeighPidTbl.TiltLinkageSensorDc; // Tilt Linkage Position Sensor Duty Cycle
        txOut.pid_data.prod_measure_sensor_status.hyd_oil_temp = WeighPidTbl.HydOilTemp;
        /* Linkage Sensor Calibrated Limits [-75722]*/
        txOut.pid_data.link_sensor_cal_lim.lift_pos_sensor_full_raise_dc = liftCalNvmTbl_.lift_full_raise_dc; // Lift Linkage Position Sensor Full Raise Duty Cycle
        txOut.pid_data.link_sensor_cal_lim.lift_pos_sensor_full_lower_dc = liftCalNvmTbl_.lift_full_lower_dc; // Lift Linkage Position Sensor Full Lower Duty Cycle
        txOut.pid_data.link_sensor_cal_lim.tilt_pos_sensor_full_rack_dc = tiltCalNvmTbl_.tilt_full_rack_dc; // Tilt Linkage Position Sensor Full Rackback Duty Cycle
        txOut.pid_data.link_sensor_cal_lim.tilt_pos_sensor_full_dump_dc = tiltCalNvmTbl_.tilt_full_dump_dc; // Tilt Linkage Position Sensor Full Dump Duty Cycle
        txOut.pid_data.pload_sys_zero_stat = static_cast<uint16_t>(GetZeroStat());/*Payload Remove Last Pass Button Display Status*/

        txOut.pid_data.loader_bkt_pload_tgt_wt = cnfg_.bucketPayloadTargetWeight;
        txOut.pid_data.loader_bkt_pload_tgt_wt_per = LpsWeighGetBucketLoadFactor();

        WeighPidTbl.PloadSysZeroReqStat = LpsWeighGetAutoZeroUpdateStatus();
        txOut.pid_data.pload_sys_zero_req_stat = static_cast<uint16_t>(WeighPidTbl.PloadSysZeroReqStat);/* Payload System Zero Requirement Status */
        txOut.pid_data.qr_hyd_oil_temp_min_c = WeighPidTbl.QR_HydOilTempMin_C;;
        txOut.pid_data.qr_lift_cyl_vel_min_mm_sec = WeighPidTbl.QR_LiftCylVelMin_mm_sec;
        txOut.pid_data.qr_lift_cyl_vel_max_mm_sec = WeighPidTbl.QR_LiftCylVelMax_mm_sec;

        txOut.payload_cal_in_progress = LpsCalCalInProgress();

        txOut.test_status = static_cast<uint8_t>(testFixture_.getTestStatus());

        // Resolve the bitset locals into the new message's raw bit fields.
        txOut.event_state.bits = static_cast<uint32_t>(eventStateBits.to_ulong());
        txOut.diag_state.bits = static_cast<uint32_t>(diagStateBits.to_ulong());
        txOut.info_state.bits = static_cast<uint32_t>(infoStateBits.to_ulong());
        txOut.pid_data.prod_measure_weigh_status = static_cast<uint16_t>(prodMeasureWeighStatusBits.to_ulong());

        /* Broadcasting Weighing App elements to ROS2 */
        bool scsCmdRet_ROS2 = LpsSaWeighScsTxOut_ROS2->publish(txOut);
        if (!scsCmdRet_ROS2) {
           RCLCPP_ERROR(ROS2Logger::Instance().GetLogger(),"[ROS2] Failed to publish LpsSaWeighTxChannel");
        }
    }

    if (!scsCmdRet) {
        RCLCPP_WARN(ROS2Logger::Instance().GetLogger(),"'LpsSaWeighingScsTx' function return code = %d", scsCmdRet);
    }

    return scsCmdRet;
}

/******************************************************************************
FUNCTION NAME: LpsSaWeighScsInitDebugTx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
*******************************************************************************/
void LpsSaWeighApp::LpsSaWeighScsInitDebugTx()
{
    if (LpsSaWeighInitDebugRosOut_ )
    {
        weigh_app_interfaces::msg::LpsSaWeighInitDebugChannel txOut;
        const LpsInitTbl_t& init = LpsWrk.InitTbl;
        txOut.exec_rate = init.ExecRate;
        txOut.cal_weight = init.MachSpecificCfg.CalibTbl.CalWeight;
        txOut.cal_status = init.MachSpecificCfg.CalibTbl.CalStatus;
        txOut.cal_adjust = init.MachSpecificCfg.CalibTbl.CalAdjust;
        txOut.zero_weight = init.MachSpecificCfg.CalibTbl.ZeroWeight;
        txOut.dig_target_wt = init.MachSpecificCfg.DigConfig.DigTargetWt;
        txOut.start_of_weigh = init.MachSpecificCfg.StartOfWeigh;
        txOut.tilt_comp_gain_scalar = init.MachSpecificCfg.TiltComp.TiltCompGainScalar;
        LpsSaWeighInitDebugRosOut_->publish(txOut);
    }
    else
    {
        /* do nothing */
    }
}

/******************************************************************************
FUNCTION NAME: LpsSaWeighScsDebugTx
DESCRIPTION:
PARAMETER DESCRIPTION:
RETURN VALUE:
 *******************************************************************************/
void LpsSaWeighApp::LpsSaWeighScsDebugTx()
{
    if (!LpsSaWeighDebugRosOut_) { return; }

    // Check for a new weigh range weight and make a log entry.
    // DebugLpsSaXCPChannels.m_LpsWrk retains the previous cycle's values for WRW transition comparison.
    if (LPS_WEIGH_WRW_STATUS_VALID == LpsWrk.WrwTbl.OpTbl.Status) {
        bool newWeighRangeWeighResults = false;

        if (LPS_WEIGH_WRW_STATUS_VALID != DebugLpsSaXCPChannels.m_LpsWrk.WrwTbl.OpTbl.Status) {
            newWeighRangeWeighResults = true;
        }
        else if ((LPS_IN_WEIGH_RANGE_WEIGHING == DebugLpsSaXCPChannels.m_LpsWrk.WrwTbl.OpTbl.Indicator) &&
                (LPS_ABOVE_WEIGH_RANGE == LpsWrk.WrwTbl.OpTbl.Indicator)) {
            newWeighRangeWeighResults = true;
        }

        if (newWeighRangeWeighResults) {
            logWeighRangeWeighUpdate();
        }
    }

    // Update staging struct (previous-cycle snapshot + debug fields set across the codebase)
    DebugLpsSaXCPChannels.m_LpsWrk = LpsWrk;

    // Build ROS2 message -- field-for-field mapping from AIS struct to snake_case ROS2 fields.
    // Field ordering follows serialize() in LpsSaWeighDebugChannel.h; types from generated struct.hpp.
    weigh_app_interfaces::msg::LpsSaWeighDebugChannel txOut;

    memcpy(&txOut.reweigh_warn, &LpsWrk.WrwTbl.ReweighWarn, sizeof(txOut.reweigh_warn));

    txOut.debug_lift_cyl_he_press        = weighUpdtTbl.LiftCylHePres.Val;
    txOut.debug_lift_cyl_he_press_status = static_cast<int32_t>(weighUpdtTbl.LiftCylHePres.Stat);
    txOut.debug_lift_cyl_re_press        = weighUpdtTbl.LiftCylRePres.Val;
    txOut.debug_lift_cyl_re_press_status = static_cast<int32_t>(weighUpdtTbl.LiftCylRePres.Stat);

    txOut.debug_tilt_cyl_he_press        = LpsSaWeighInfoTbl.TiltCylHePres.Val;
    txOut.debug_tilt_cyl_he_press_status = static_cast<int32_t>(LpsSaWeighInfoTbl.TiltCylHePres.Stat);
    txOut.debug_tilt_cyl_re_press        = LpsSaWeighInfoTbl.TiltCylRePres.Val;
    txOut.debug_tilt_cyl_re_press_status = static_cast<int32_t>(LpsSaWeighInfoTbl.TiltCylRePres.Stat);

    txOut.debug_lift_cyl_raw_ext         = LpsSaWeighInfoTbl.LiftPosition.cylinderLength;
    txOut.debug_lift_cyl_filt_ext        = LpsSaWeighInfoTbl.LiftPosition.cylinderLength;
    txOut.debug_lift_cyl_norm_len        = LpsSaWeighInfoTbl.LiftPosition.percentCylinderLength;
    txOut.debug_lift_cyl_vel             = LpsSaWeighInfoTbl.LiftCylVel.Val;
    txOut.debug_lift_angle               = LpsSaWeighInfoTbl.LiftPosition.angle;
    txOut.debug_lift_ang_vel             = LpsSaWeighInfoTbl.LiftAngVel.Val;
    txOut.debug_lift_position_status     = static_cast<int32_t>(LpsSaWeighInfoTbl.LiftPosition.status);

    txOut.debug_tilt_cyl_raw_len         = LpsSaWeighInfoTbl.TiltPosition.cylinderLength;
    txOut.debug_tilt_cyl_norm_len        = LpsSaWeighInfoTbl.TiltPosition.percentCylinderLength;
    txOut.debug_tilt_cyl_vel             = LpsSaWeighInfoTbl.TiltCylVel.Val;
    txOut.debug_tilt_angle               = LpsSaWeighInfoTbl.TiltPosition.angle;
    txOut.debug_tilt_angle_abc           = LpsSaWeighInfoTbl.TiltPosition.percentAngle;
    txOut.debug_tilt_position_status     = static_cast<int32_t>(LpsSaWeighInfoTbl.TiltPosition.status);

    txOut.debug_bucket_angle             = weighUpdtTbl.BktAngle.Val;
    txOut.debug_bucket_angle_status      = static_cast<int32_t>(weighUpdtTbl.BktAngle.Stat);
    txOut.debug_hyd_oil_temp             = weighUpdtTbl.HydOilTemp.Val;
    txOut.debug_hyd_oil_temp_status      = static_cast<int32_t>(weighUpdtTbl.HydOilTemp.Stat);
    txOut.debug_requested_gear           = weighUpdtTbl.RequestedGear.Val;
    txOut.debug_requested_gear_status    = static_cast<int32_t>(weighUpdtTbl.RequestedGear.Stat);
    txOut.debug_weigh_updt_loader_bkt_payld_trgt_wt = weighUpdtTbl.LoaderBktPayldTrgtWt;
    txOut.debug_weigh_updt_clock_keyon_sec           = weighUpdtTbl.ClockKeyonSec;
    txOut.debug_weigh_updt_pass_count                = weighUpdtTbl.PassCount;

    // LpsWrkTbl_t m_LpsWrk fields (flattened)
    txOut.best_bkt_wt_payload_calc_meth              = LpsWrk.BestBktWt.PayloadCalcMeth;
    txOut.best_bkt_wt_wt                             = LpsWrk.BestBktWt.Wt;
    txOut.best_bkt_wt_tipoff_live_weight_in_use      = LpsWrk.BestBktWt.TipoffLiveWeightInUse;
    txOut.cyl_flow_const_lift_he_flow_const          = LpsWrk.CylFlowConst.LiftHeFlowConst;
    txOut.cyl_flow_const_lift_re_to_he_flow_ratio    = LpsWrk.CylFlowConst.LiftReToHeFlowRatio;
    txOut.dig_detect_data_dig_detected               = LpsWrk.DigDetectData.DigDetected;
    txOut.dig_detect_data_dig_duration               = LpsWrk.DigDetectData.DigDuration;
    txOut.dig_detect_data_dig_started                = LpsWrk.DigDetectData.DigStarted;
    txOut.dig_detect_data_dig_state                  = static_cast<uint8_t>(LpsWrk.DigDetectData.DigState);
    txOut.dig_detect_data_wt_stabilized              = LpsWrk.DigDetectData.WtStabilized;
    txOut.dump_wt_change_data_dump_cumulative_wt_change = LpsWrk.DumpWtChangeData.DumpCumulativeWtChange;
    txOut.inst_wt_der                                = LpsWrk.InstWtDer;
    txOut.inst_wt_filt                               = LpsWrk.InstWtFilt;
    txOut.inst_wt_llw_filt                           = LpsWrk.InstWtLlwFilt;
    txOut.inst_wt_raw.stat                           = static_cast<int32_t>(LpsWrk.InstWtRaw.Stat);
    txOut.inst_wt_raw.val                            = LpsWrk.InstWtRaw.Val;
    txOut.inst_wt_raw_pre_tilt_comp                  = LpsWrk.InstWtRawPreTiltComp;
    txOut.inst_wt_raw_post_tilt_comp                 = LpsWrk.InstWtRawPostTiltComp;
    txOut.lift_cyl_pressure                          = LpsWrk.LiftCylPressure;
    txOut.lift_cyl_pressure_v0                       = LpsWrk.LiftCylPressureV0;
    txOut.lift_cyl_pressure_imu_adjusted             = LpsWrk.LiftCylPressureIMUAdjusted;
    txOut.live_weigh_tbl_stat                        = static_cast<uint8_t>(LpsWrk.LiveWeighTbl.Stat);
    txOut.live_weigh_tbl_wt                          = LpsWrk.LiveWeighTbl.Wt;
    txOut.live_weigh_tbl_use_fast_filter             = LpsWrk.LiveWeighTbl.UseFastFilter;
    txOut.low_lift_wt_wt                             = LpsWrk.LowLiftWt.Wt;
    txOut.low_lift_wt_confidence                     = LpsWrk.LowLiftWt.Confidence;
    txOut.low_lift_wt_confidence_est                 = LpsWrk.LowLiftWt.ConfidenceEst;
    txOut.low_lift_wt_confidence_timer               = LpsWrk.LowLiftWt.ConfidenceTimer;
    txOut.low_lift_wt_last_input                     = LpsWrk.LowLiftWt.LastInput;
    txOut.low_lift_wt_mean_est                       = LpsWrk.LowLiftWt.MeanEst;
    txOut.low_lift_wt_mean_est_comp                  = LpsWrk.LowLiftWt.MeanEstComp;
    txOut.low_lift_wt_stat                           = static_cast<uint8_t>(LpsWrk.LowLiftWt.Stat);
    txOut.low_lift_wt_stdev_est                      = LpsWrk.LowLiftWt.StdevEst;
    txOut.low_lift_wt_variance_est                   = LpsWrk.LowLiftWt.VarianceEst;
    txOut.dump_state_status                          = static_cast<uint8_t>(LpsWrk.DumpStateStatus);
    txOut.lps_stall_detect_lift_stalled              = LpsWrk.LpsStallDetect.liftStalled;
    txOut.linkage_movement_lift                      = static_cast<float>(LpsWrk.LinkageMovement.lift);
    txOut.linkage_movement_tilt                      = static_cast<float>(LpsWrk.LinkageMovement.tilt);
    txOut.wrw_tbl_wk_tbl_result_weight_ave_raw       = LpsWrk.WrwTbl.WkTbl.result.weightAveRaw;
    txOut.wrw_tbl_wk_tbl_result_weight_ave           = LpsWrk.WrwTbl.WkTbl.result.weightAve;
    txOut.wrw_tbl_op_tbl_wt                          = LpsWrk.WrwTbl.OpTbl.Wt;
    txOut.wrw_tbl_op_tbl_warning                     = LpsWrk.WrwTbl.OpTbl.Warning;
    txOut.wrw_tbl_op_tbl_indicator                   = static_cast<int32_t>(LpsWrk.WrwTbl.OpTbl.Indicator);
    txOut.wrw_tbl_op_tbl_status                      = static_cast<uint8_t>(LpsWrk.WrwTbl.OpTbl.Status);
    txOut.wrw_tbl_wk_tbl_result_weight_ave_raw_imu_comp = LpsWrk.WrwTbl.WkTbl.result.weightAveRawIMUComp;
    txOut.wrw_tbl_wk_tbl_been_below_range            = LpsWrk.WrwTbl.WkTbl.BeenBelowRange;
    txOut.zero_adj_tbl_zero_adj_status               = static_cast<uint8_t>(LpsWrk.ZeroAdjTbl.ZeroAdjStatus);
    txOut.overload_warn_tbl_bucket_load_factor        = LpsWrk.OverloadWarnTbl.BucketLoadFactor;
    txOut.overload_warn_tbl_dig_reverse_flag          = LpsWrk.OverloadWarnTbl.DigReverseFlag;
    txOut.overload_warn_tbl_in_overload_range         = LpsWrk.OverloadWarnTbl.InOverloadRange;
    txOut.overload_warn_tbl_level                     = static_cast<uint8_t>(LpsWrk.OverloadWarnTbl.Level);
    txOut.overload_warn_tbl_prev_dig_state            = static_cast<uint8_t>(LpsWrk.OverloadWarnTbl.PrevDigState);
    txOut.lift_position_filt_length                   = LpsWrk.LiftPositionFilt.length;
    txOut.lift_position_filt_velocity                 = LpsWrk.LiftPositionFilt.velocity;
    txOut.lift_position_filt_angle                    = LpsWrk.LiftPositionFilt.angle;

    // TipoffAssist inputs/outputs — sourced from LpsSaWeighInfoTbl (live cycle data)
    txOut.tipoff_inputs.input_status                  = LpsSaWeighInfoTbl.TipoffInputs.input_status.data;
    txOut.tipoff_inputs.invalidate_outputs            = LpsSaWeighInfoTbl.TipoffInputs.invalidate_outputs;
    txOut.tipoff_inputs.lift_valve_cmd                = LpsSaWeighInfoTbl.TipoffInputs.lift_valve_cmd;
    txOut.tipoff_inputs.tilt_valve_cmd                = LpsSaWeighInfoTbl.TipoffInputs.tilt_valve_cmd;
    txOut.tipoff_inputs.tilt_extension                = LpsSaWeighInfoTbl.TipoffInputs.tilt_extension;
    txOut.tipoff_inputs.lift_angle                    = LpsSaWeighInfoTbl.TipoffInputs.lift_angle;
    txOut.tipoff_inputs.lift_he_pressure              = LpsSaWeighInfoTbl.TipoffInputs.lift_he_pressure;
    txOut.tipoff_inputs.lift_re_pressure              = LpsSaWeighInfoTbl.TipoffInputs.lift_re_pressure;
    txOut.tipoff_inputs.tilt_he_pressure              = LpsSaWeighInfoTbl.TipoffInputs.tilt_he_pressure;
    txOut.tipoff_inputs.tilt_re_pressure              = LpsSaWeighInfoTbl.TipoffInputs.tilt_re_pressure;
    txOut.tipoff_inputs.eef_imu_accel_x               = LpsSaWeighInfoTbl.TipoffInputs.eef_imu_accelX;
    txOut.tipoff_inputs.eef_imu_accel_y               = LpsSaWeighInfoTbl.TipoffInputs.eef_imu_accelY;
    txOut.tipoff_inputs.eef_imu_accel_z               = LpsSaWeighInfoTbl.TipoffInputs.eef_imu_accelZ;
    txOut.tipoff_inputs.steering_angle                = LpsSaWeighInfoTbl.TipoffInputs.steering_angle;
    txOut.tipoff_inputs.tool_mass                     = LpsSaWeighInfoTbl.TipoffInputs.tool_mass;
    txOut.tipoff_inputs.truck_target_wt               = LpsSaWeighInfoTbl.TipoffInputs.truck_target_wt;
    txOut.tipoff_inputs.truck_start_weight            = LpsSaWeighInfoTbl.TipoffInputs.truck_start_weight;
    txOut.tipoff_inputs.bucket_current_weight_accuracy = LpsSaWeighInfoTbl.TipoffInputs.bucket_current_weight_accuracy;
    txOut.tipoff_inputs.bucket_current_weight         = LpsSaWeighInfoTbl.TipoffInputs.bucket_current_weight;
    txOut.tipoff_inputs.tipoff_mode                   = LpsSaWeighInfoTbl.TipoffInputs.tipoff_mode;
    txOut.tipoff_inputs.zero_offset                   = LpsSaWeighInfoTbl.TipoffInputs.zero_offset;
    txOut.tipoff_inputs.simple_cal_factor             = LpsSaWeighInfoTbl.TipoffInputs.simple_cal_factor;
    txOut.tipoff_inputs.unlatch_trigger               = LpsSaWeighInfoTbl.TipoffInputs.unlatch_trigger;
    txOut.tipoff_inputs.bucket_angle                  = LpsSaWeighInfoTbl.TipoffInputs.bucket_angle;
    txOut.tipoff_inputs.anchor_zero_offset            = LpsSaWeighInfoTbl.TipoffInputs.anchor_zero_offset;
    txOut.tipoff_inputs.anchor_factor                 = LpsSaWeighInfoTbl.TipoffInputs.anchor_factor;
    txOut.tipoff_inputs.pass_count                    = LpsSaWeighInfoTbl.TipoffInputs.pass_count;
    txOut.tipoff_inputs.lift_norm_angle               = LpsSaWeighInfoTbl.TipoffInputs.lift_norm_angle;
    txOut.tipoff_inputs.lift_norm_length              = LpsSaWeighInfoTbl.TipoffInputs.lift_norm_length;
    txOut.tipoff_inputs.tilt_norm_angle               = LpsSaWeighInfoTbl.TipoffInputs.tilt_norm_angle;
    txOut.tipoff_inputs.tilt_norm_length              = LpsSaWeighInfoTbl.TipoffInputs.tilt_norm_length;
    txOut.tipoff_inputs.friction_mu                   = LpsSaWeighInfoTbl.TipoffInputs.friction_mu;
    txOut.tipoff_inputs.friction_offset               = LpsSaWeighInfoTbl.TipoffInputs.friction_offset;

    if (nullptr != LpsSaWeighInfoTbl.TipoffOutputsPtr) {
        const TipoffAssistOutputs& tipOut = *LpsSaWeighInfoTbl.TipoffOutputsPtr;
        txOut.tipoff_outputs.tilt_sensitivity_out                  = tipOut.tilt_sensitivity_out;
        txOut.tipoff_outputs.tilt_pressure_out                     = tipOut.tilt_pressure_out;
        txOut.tipoff_outputs.arbitrated_payload_norm_error_out     = tipOut.arbitrated_payload_norm_error_out;
        txOut.tipoff_outputs.weigh_status_out                      = tipOut.weigh_status_out;
        txOut.tipoff_outputs.payload_norm_stdev_out                = tipOut.payload_norm_stdev_out;
        txOut.tipoff_outputs.pcs_weight_accuracy_out               = tipOut.pcs_weight_accuracy_out;
        txOut.tipoff_outputs.current_weight_norm_error_out         = tipOut.current_weight_norm_error_out;
        txOut.tipoff_outputs.error_code_out                        = tipOut.error_code_out;
        txOut.tipoff_outputs.spill_rate_out                        = tipOut.spill_rate_out;
        txOut.tipoff_outputs.payload_send_to_cpm                   = tipOut.payload_send_to_CPM;
        txOut.tipoff_outputs.payload_status_send_to_cpm            = tipOut.payload_status_send_to_CPM;
        txOut.tipoff_outputs.bucket_payload_target                 = tipOut.bucket_payload_target;
        txOut.tipoff_outputs.unsecured_payload_upper_bound_norm    = tipOut.unsecured_payload_upper_bound_norm;
        txOut.tipoff_outputs.unsecured_payload_lower_bound_norm    = tipOut.unsecured_payload_lower_bound_norm;
        txOut.tipoff_outputs.unsecured_pfw_status                  = tipOut.unsecured_PFW_status;
        txOut.tipoff_outputs.min_secure_bucket_angle               = tipOut.min_secure_bucket_angle;
    }

    // Chassis IMU
    { auto gravityVector = chassisImu_.imu.gravityVector();
      txOut.chassis_imu_gravity_x = gravityVector.x();
      txOut.chassis_imu_gravity_y = gravityVector.y();
      txOut.chassis_imu_gravity_z = gravityVector.z(); }

    { auto vel = chassisImu_.imu.estimatedLinVelVector();
      txOut.chassis_imu_velocity_x = vel.x();
      txOut.chassis_imu_velocity_y = vel.y();
      txOut.chassis_imu_velocity_z = vel.z(); }

    txOut.chassis_imu_bias_mag_jerk     = chassisImu_.imu.magJerk_;
    txOut.chassis_imu_bias_mag_ang_accel = chassisImu_.imu.magAngAccel_;
    txOut.chassis_imu_bias_max_ang_vel  = chassisImu_.imu.maxAngVel_;

    { auto biasAngVel = chassisImu_.imu.biasAngVelVector();
      txOut.chassis_imu_bias_ang_vel_x = biasAngVel.x();
      txOut.chassis_imu_bias_ang_vel_y = biasAngVel.y();
      txOut.chassis_imu_bias_ang_vel_z = biasAngVel.z(); }

    { auto linAcc = chassisImu_.sensorLinAcc;
      txOut.chassis_imu_lin_acc_x = linAcc.x();
      txOut.chassis_imu_lin_acc_y = linAcc.y();
      txOut.chassis_imu_lin_acc_z = linAcc.z(); }

    { auto angVel = chassisImu_.sensorAngVel;
      txOut.chassis_imu_ang_vel_x = angVel.x();
      txOut.chassis_imu_ang_vel_y = angVel.y();
      txOut.chassis_imu_ang_vel_z = angVel.z(); }

    txOut.chassis_imu_pitch                  = chassisImu_.imu.pitchDegrees();
    txOut.chassis_imu_roll                   = chassisImu_.imu.rollDegrees();
    txOut.chassis_imu_sensor_lin_acc_status  = chassisImu_.sensorLinAccStatus;
    txOut.chassis_imu_sensor_ang_vel_status  = chassisImu_.sensorAngVelStatus;

    // Publish to ROS2 (AIS SCS leg forwarded by ScsToRos2Bridge)
    LpsSaWeighDebugRosOut_->publish(txOut);
}

/******************************************************************************
FUNCTION: PublishCalFromNvmPayload
DESCRIPTION: Prepares an SCS object with the key-on available calibration data and send the data out
PARAMETER DESCRIPTION: None
RETURN VALUE: None
*******************************************************************************/
void LpsSaWeighApp::PublishCalFromNvmPayload( void )
{
   if (!LpsNvmCalRosOut_) { return; }

  RCLCPP_INFO(ROS2Logger::Instance().GetLogger(),"Populating ROS2 msg with key-on NVM calibration data");
   weigh_app_interfaces::msg::LpsSaNvmCalDataChannel rosPayload;
   auto& main  = rosPayload.lps_sa_nvm_calibration_data_main;
   auto& debug = rosPayload.lps_sa_nvm_calibration_data_debug;

   std::copy(std::begin(payloadCalNvmTbl_.data.SlowRaiseEmptyBktLiftHt),
             std::end(payloadCalNvmTbl_.data.SlowRaiseEmptyBktLiftHt),
             main.raise_slow_empty_lift_heights.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowRaiseEmptyBktLiftPres),
             std::end(payloadCalNvmTbl_.data.SlowRaiseEmptyBktLiftPres),
             main.raise_slow_empty_pressures.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowLowerEmptyBktLiftHt),
             std::end(payloadCalNvmTbl_.data.SlowLowerEmptyBktLiftHt),
             main.lower_slow_empty_lift_heights.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowLowerEmptyBktLiftPres),
             std::end(payloadCalNvmTbl_.data.SlowLowerEmptyBktLiftPres),
             main.lower_slow_empty_pressures.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowRaiseFullBktLiftHt),
             std::end(payloadCalNvmTbl_.data.SlowRaiseFullBktLiftHt),
             main.raise_slow_full_lift_heights.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowRaiseFullBktLiftPres),
             std::end(payloadCalNvmTbl_.data.SlowRaiseFullBktLiftPres),
             main.raise_slow_full_pressures.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowLowerFullBktLiftHt),
             std::end(payloadCalNvmTbl_.data.SlowLowerFullBktLiftHt),
             main.lower_slow_full_lift_heights.begin());
   std::copy(std::begin(payloadCalNvmTbl_.data.SlowLowerFullBktLiftPres),
             std::end(payloadCalNvmTbl_.data.SlowLowerFullBktLiftPres),
             main.lower_slow_full_pressures.begin());

   main.raise_speed_empty_slow  = payloadCalNvmTbl_.data.EmptyBktSlowRaiseSpd;
   main.raise_speed_empty_fast  = payloadCalNvmTbl_.data.EmptyBktFastRaiseSpd;
   main.raise_fast_delta_p_empty = payloadCalNvmTbl_.data.FastRaiseEmptyBktDeltaPres;
   main.raise_speed_full_slow   = payloadCalNvmTbl_.data.FullBktSlowRaiseSpd;
   main.raise_speed_full_fast   = payloadCalNvmTbl_.data.FullBktFastRaiseSpd;
   main.raise_fast_delta_p_full  = payloadCalNvmTbl_.data.FastRaiseFullBktDeltaPres;

   debug.lift_full_lower_dc_inf_value    = static_cast<int32_t>(liftCalNvmTbl_.lift_full_lower_dc);
   debug.lift_full_raise_dc_inf_value    = static_cast<int32_t>(liftCalNvmTbl_.lift_full_raise_dc);
   debug.tilt_full_dump_dc_inf_value     = static_cast<int32_t>(tiltCalNvmTbl_.tilt_full_dump_dc);
   debug.tilt_full_rack_dc_inf_value     = static_cast<int32_t>(tiltCalNvmTbl_.tilt_full_rack_dc);
   debug.tilt_dump_stop_angle_inf_value  = static_cast<int32_t>(tiltCalNvmTbl_.tilt_full_dump_stop_angle);
   debug.tilt_rack_stop_angle_inf_value  = static_cast<int32_t>(tiltCalNvmTbl_.tilt_full_rack_stop_angle);
   debug.pcs_cal_weight                  = payloadCalNvmTbl_.data.CalWeight;
   debug.zero_weight                     = payloadCalNvmTbl_.data.ZeroWeight;
   debug.cal_adjust                      = payloadCalNvmTbl_.data.CalAdjust;
   debug.empty_temp                      = payloadCalNvmTbl_.data.EmptyTemp;
   debug.full_temp                       = payloadCalNvmTbl_.data.FullTemp;
   debug.empty_bucket_weight_est         = payloadCalNvmTbl_.data.EmptyBucketWeightEst;
   debug.hyd_oil_type_index              = static_cast<int32_t>(LpsSaInitTbl.WeighInitTbl.MachSpecificCfg.HydOilType);
   /* pcs_vel_slope, temp_slope, cal_adjust_temp not yet populated (same as original) */

   LpsCalIMUResults_t imu = {};
   readIMUCalResultsFromFile(imu);
   rosPayload.imu_cal_results.full_slow_imu_offset_temp1      = imu.FullSlowImuOffsetTemp1;
   rosPayload.imu_cal_results.full_slow_imu_offset_temp2      = imu.FullSlowImuOffsetTemp2;
   rosPayload.imu_cal_results.full_slow_imu_offset_temp3      = imu.FullSlowImuOffsetTemp3;
   rosPayload.imu_cal_results.full_slow_lumped_weight_temp1   = imu.FullSlowLumpedWeightTemp1;
   rosPayload.imu_cal_results.full_slow_lumped_weight_temp2   = imu.FullSlowLumpedWeightTemp2;
   rosPayload.imu_cal_results.full_slow_lumped_weight_temp3   = imu.FullSlowLumpedWeightTemp3;
   rosPayload.imu_cal_results.empty_slow_imu_offset_temp1     = imu.EmptySlowImuOffsetTemp1;
   rosPayload.imu_cal_results.empty_slow_imu_offset_temp2     = imu.EmptySlowImuOffsetTemp2;
   rosPayload.imu_cal_results.empty_slow_imu_offset_temp3     = imu.EmptySlowImuOffsetTemp3;
   rosPayload.imu_cal_results.empty_slow_lumped_weight_temp1  = imu.EmptySlowLumpedWeightTemp1;
   rosPayload.imu_cal_results.empty_slow_lumped_weight_temp2  = imu.EmptySlowLumpedWeightTemp2;
   rosPayload.imu_cal_results.empty_slow_lumped_weight_temp3  = imu.EmptySlowLumpedWeightTemp3;
   rosPayload.imu_cal_results.full_slow_imu_offset_final      = imu.FullSlowImuOffsetFinal;
   rosPayload.imu_cal_results.empty_slow_imu_offset_final     = imu.EmptySlowImuOffsetFinal;
   rosPayload.imu_cal_results.full_slow_lumped_weight_final   = imu.FullSlowLumpedWeightFinal;
   rosPayload.imu_cal_results.empty_slow_lumped_weight_final  = imu.EmptySlowLumpedWeightFinal;

   LpsNvmCalRosOut_->publish(rosPayload);
}



