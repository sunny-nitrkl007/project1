# TipoffModelTestPointsOutput — Port Summary

**Direction:** WeighApp/TipoffAssist (ROS2 publisher) → ScsToRos2Bridge → AIS SCS → aisXcpServer (XCP/CANape diagnostics)  
**Commit:** `725c4e3f`  
**Branch:** `CPM_Porting_WeighDebugChannel`

## What changed

### `apps/LpsSaWeighApp/adv/TipoffAssist.h`
- Removed `#include <interfaces/TipoffModelTestPoints/InterfaceTypes.h>`
- Added `#include "rclcpp/rclcpp.hpp"`, `"ros2wrapper/RosOutputInterface.h"`, `<weigh_app_interfaces/msg/tipoff_model_test_points.hpp>`
- Removed `TipoffModelTestPoints TipoffModelTestPointsData` (staging struct) and `TipoffModelTestPointsOutput* TipoffModelTestPointsOut`
- Added `ros2_wrapper::RosOutputInterface<weigh_app_interfaces::msg::TipoffModelTestPoints>* TipoffModelTestPointsRosOut_`
- `initialize()` signature: added `rclcpp::Node::SharedPtr rosNode` parameter

### `apps/LpsSaWeighApp/adv/TipoffAssist.cpp`
| Location | Change |
|---|---|
| Constructor | `TipoffModelTestPointsOut(nullptr)` → `TipoffModelTestPointsRosOut_(nullptr)` |
| `initialize()` | Removed `InterfaceDb::bind("TipoffModelTestPointsOutput", ...)` → `new RosOutputInterface<TipoffModelTestPoints>(rosNode, "tipoff_model_test_points")` |
| `update()` | Removed 76-field `TipoffModelTestPointsData.*` staging block. Builds `weigh_app_interfaces::msg::TipoffModelTestPoints txOut` directly; all 76 fields mapped from `toa_wl00_work.BlockIO.*` and `toa_wl00_catParameters_si_RAM.*`. Publishes via `TipoffModelTestPointsRosOut_->publish(txOut)`. |

### `apps/LpsSaWeighApp/adv/LpsAdvProcessInputs.cpp`
- `LpsTipoffAssist.initialize(machineProperties)` → `LpsTipoffAssist.initialize(machineProperties, rosNode_)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added `#include <interfaces/TipoffModelTestPoints/InterfaceTypes.h>` and `<weigh_app_interfaces/msg/tipoff_model_test_points.hpp>`
- Added SCS member: `TipoffModelTestPointsOutput* tipoffTestPointsScsOut_`
- Added ROS2 member: `unique_ptr<RosInputInterface<TipoffModelTestPoints>> tipoffTestPointsRosIn_`
- Added declaration: `static TipoffModelTestPoints convertTipoffTestPointsToScs(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `tipoffTestPointsScsOut_(nullptr)` |
| `initialize()` | `InterfaceDb::bind("TipoffModelTestPointsOutput", ...)` — **WARN only, non-fatal**; `make_unique` for `tipoffTestPointsRosIn_` |
| `executive()` | Drain loop: ROS2 → AIS SCS via `convertTipoffTestPointsToScs()` → `tipoffTestPointsScsOut_->publish()` |
| End of file | `convertTipoffTestPointsToScs()` — 76-field reverse mapping (snake_case ROS2 → camelCase AIS) |

### `config/LpsSaWeighApp.rb`
- Removed `"TipoffModelTestPointsOutput"` binding

### `config/ScsToRos2Bridge.rb`
- Added `"TipoffModelTestPointsOutput"` binding
