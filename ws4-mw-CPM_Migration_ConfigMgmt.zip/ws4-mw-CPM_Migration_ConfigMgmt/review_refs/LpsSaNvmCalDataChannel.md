# LpsSaNvmCalDataChannel — Port Summary

**Direction:** WeighApp → ROS2 → ScsToRos2Bridge → AIS SCS → aisXcpServer  
**Commits:** `fe09c8e4` (WeighApp), `4ed6c02a` (Bridge)  
**Branch:** `CPM_Porting_WeighDebugChannel`

## What changed

### `apps/LpsSaWeighApp/LpsSaWeighApp.h`
- Removed `LpsSaNvmCalDataChannelOutput* LpsNvmDumpChanOut`
- Added `ros2_wrapper::RosOutputInterface<weigh_app_interfaces::msg::LpsSaNvmCalDataChannel>* LpsNvmCalRosOut_`
- Added `#include <weigh_app_interfaces/msg/lps_sa_nvm_cal_data_channel.hpp>`
- Removed `#include <interfaces/LpsSaNvmCalDataChannel/InterfaceTypes.h>`

### `apps/LpsSaWeighApp/LpsSaWeighApp.cpp`
| Location | Change |
|---|---|
| Constructor | `LpsNvmDumpChanOut(nullptr)` → `LpsNvmCalRosOut_(nullptr)` |
| `initialize()` | Removed `InterfaceDb::bind("LpsSaNvmCalDataChannelOutput", ...)` → added `new RosOutputInterface<...>(rosNode_, "lps_sa_nvm_cal_data_channel")` |

### `apps/LpsSaWeighApp/LpsSaScs.cpp`
| Function | Change |
|---|---|
| `PublishCalFromNvmPayload()` | Guard added `if (!LpsNvmCalRosOut_) { return; }`. Builds `weigh_app_interfaces::msg::LpsSaNvmCalDataChannel rosPayload`. `memcpy` replaced with `std::copy` for `std::array` targets. IMU fields mapped field-by-field. Publishes via `LpsNvmCalRosOut_->publish(rosPayload)`. |

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added includes: `lps_sa_nvm_cal_data_channel.hpp`, `LpsSaNvmCalDataChannel/InterfaceTypes.h`
- Added SCS member: `LpsSaNvmCalDataChannelOutput* nvmCalDataScsOut_`
- Added ROS2 member: `unique_ptr<RosInputInterface<LpsSaNvmCalDataChannel>> nvmCalDataRosIn_`
- Added declaration: `static LpsSaNvmCalDataChannel convertNvmCalDataToScs(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `nvmCalDataScsOut_(nullptr)`, `nvmCalDataRosIn_()` |
| `initialize()` | Bind `LpsSaNvmCalDataChannelOutput`; `make_unique` for `nvmCalDataRosIn_` |
| `executive()` | Drain loop: ROS2 → AIS SCS via `convertNvmCalDataToScs()` |
| End of file | `convertNvmCalDataToScs()` — full field + 16 IMU field reverse mapping, `std::copy` for arrays |

### `config/ScsToRos2Bridge.rb`
- Added `"LpsSaNvmCalDataChannelOutput"` binding

### `config/LpsSaWeighApp.rb`
- Removed `"LpsSaNvmCalDataChannelOutput"` binding
