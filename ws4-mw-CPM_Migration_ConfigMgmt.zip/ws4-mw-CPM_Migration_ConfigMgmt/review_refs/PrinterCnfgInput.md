# PrinterCnfgInput — Port Summary

**Direction:** LpsSaTotalsApp (AIS SCS producer) → ScsToRos2Bridge → ROS2 → WeighApp (subscriber)  
**Commit:** `725c4e3f`  
**Branch:** `CPM_Porting_WeighDebugChannel`

## Context
Only one field is consumed by WeighApp: `truck_ticket.retention_period` (passed to `sealTracker_.reportTicketRetentionPeriod()`). Full struct is mapped in bridge conversion for completeness.

## What changed

### `apps/LpsSaWeighApp/LpsSaWeighApp.h`
- Removed `#include <interfaces/LpsSaTotals/PrinterCnfgInterfaceInputChannel.h>`
- Added `#include <weigh_app_interfaces/msg/lps_sa_totals_printer_cnfg.hpp>`
- `LpsSaTotalsPrinterCnfgInterfaceInputChannel* printerCnfgInput_` → `ros2_wrapper::RosInputInterface<weigh_app_interfaces::msg::LpsSaTotalsPrinterCnfg>* printerCnfgInput_`

### `apps/LpsSaWeighApp/LpsSaWeighApp.cpp`
| Location | Change |
|---|---|
| Constructor | `printerCnfgInput_(nullptr)` — unchanged |
| `initialize()` | Removed `InterfaceDb::bind("PrinterCnfgInput", ...)` + `return false` → `new RosInputInterface<LpsSaTotalsPrinterCnfg>(rosNode_, "lps_sa_totals_printer_cnfg")` with hard-fail (`return false`) preserved |

### `apps/LpsSaWeighApp/LpsSaScs.cpp`
| Function | Change |
|---|---|
| `LpsSaWeighScsDebugTx()` | `LpsSaTotalsPrinterCnfgInterface printerCnfg` → `weigh_app_interfaces::msg::LpsSaTotalsPrinterCnfg printerCnfg`. Field access: `printerCnfg.config.truckTicket.retentionPeriod` → `printerCnfg.truck_ticket.retention_period` |

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added `#include <interfaces/LpsSaTotals/PrinterCnfgInterfaceInputChannel.h>` and `<weigh_app_interfaces/msg/lps_sa_totals_printer_cnfg.hpp>`
- Added SCS member: `LpsSaTotalsPrinterCnfgInterfaceInputChannel* printerCnfgScsIn_`
- Added ROS2 member: `unique_ptr<RosOutputInterface<LpsSaTotalsPrinterCnfg>> printerCnfgRosOut_`
- Added declaration: `static weigh_app_interfaces::msg::LpsSaTotalsPrinterCnfg convertPrinterCnfgToRos(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `printerCnfgScsIn_(nullptr)` |
| `initialize()` | `InterfaceDb::bind("PrinterCnfgInput", ...)` — **HARD FAILURE**, `everythingOk = false`; `make_unique` for `printerCnfgRosOut_` |
| `executive()` | Drain loop: AIS SCS `printerCnfgScsIn_->get()` → `convertPrinterCnfgToRos()` → `printerCnfgRosOut_->publish()` |
| End of file | `convertPrinterCnfgToRos()` — maps `installed`, `leadingBlankLines`, `trailingBlankLines`, `dateFormat`, `dateSeparator`, full `truckTicket` (9 fields), `truckReport.resetTimeEnabled`, `materialReport.resetTimeEnabled`, `udpTransfer*` |

### `config/LpsSaWeighApp.rb`
- Removed `"PrinterCnfgInput"` binding

### `config/ScsToRos2Bridge.rb`
- Added `"PrinterCnfgInput"` binding
