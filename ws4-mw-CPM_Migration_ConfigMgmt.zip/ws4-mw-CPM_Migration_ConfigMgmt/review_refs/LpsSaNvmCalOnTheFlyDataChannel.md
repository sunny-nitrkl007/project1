# LpsSaNvmCalOnTheFlyDataChannel — Port Summary

**Direction:** WeighApp → ROS2 → ScsToRos2Bridge → AIS SCS → aisXcpServer  
**Commits:** `fe09c8e4` (WeighApp), `4ed6c02a` (Bridge)  
**Branch:** `CPM_Porting_WeighDebugChannel`

## What changed

### `apps/LpsSaWeighApp/LpsSaWeighApp.h`
- Removed `LpsSaNvmCalOnTheFlyDataChannelOutput* LpsNvmOnTheFlyDumpChanOut`
- Added `ros2_wrapper::RosOutputInterface<weigh_app_interfaces::msg::LpsSaNvmCalOnTheFlyDataChannel>* LpsNvmCalOnTheFlyRosOut_`
- Added `#include <weigh_app_interfaces/msg/lps_sa_nvm_cal_on_the_fly_data_channel.hpp>`
- Removed `#include <interfaces/LpsSaNvmCalOnTheFlyDataChannel/InterfaceTypes.h>`

### `apps/LpsSaWeighApp/LpsSaWeighApp.cpp`
| Location | Change |
|---|---|
| Constructor | `LpsNvmOnTheFlyDumpChanOut(nullptr)` → `LpsNvmCalOnTheFlyRosOut_(nullptr)` |
| `initialize()` | Removed `InterfaceDb::bind("LpsSaNvmCalOnTheFlyDataChannelOutput", ...)` → added `new RosOutputInterface<...>(rosNode_, "lps_sa_nvm_cal_on_the_fly_data_channel")` |
| `LpsSaWeighCalReqstCallback()` | `LpsSaNvmCalOnTheFlyDataChannel calOtfData` → `weigh_app_interfaces::msg::LpsSaNvmCalOnTheFlyDataChannel calOtfData`. All field assignments rewritten to ROS2 snake_case names (`otf.status_flags.*`, `otf.curve_info.*`, `otf.cal_updates.*`, `otf.cal_overrides.*`). IMU mapped field-by-field. Duplicate `LowerSlowFitDone` assignment removed. Publishes via `LpsNvmCalOnTheFlyRosOut_->publish(calOtfData)`. |

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added includes: `lps_sa_nvm_cal_on_the_fly_data_channel.hpp`, `LpsSaNvmCalOnTheFlyDataChannel/InterfaceTypes.h`
- Added SCS member: `LpsSaNvmCalOnTheFlyDataChannelOutput* nvmCalOnTheFlyDataScsOut_`
- Added ROS2 member: `unique_ptr<RosInputInterface<LpsSaNvmCalOnTheFlyDataChannel>> nvmCalOnTheFlyDataRosIn_`
- Added declaration: `static LpsSaNvmCalOnTheFlyDataChannel convertNvmCalOnTheFlyDataToScs(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `nvmCalOnTheFlyDataScsOut_(nullptr)`, `nvmCalOnTheFlyDataRosIn_()` |
| `initialize()` | Bind `LpsSaNvmCalOnTheFlyDataChannelOutput`; `make_unique` for `nvmCalOnTheFlyDataRosIn_` |
| `executive()` | Drain loop: ROS2 → AIS SCS via `convertNvmCalOnTheFlyDataToScs()` |
| End of file | `convertNvmCalOnTheFlyDataToScs()` — statusFlags, calUpdates (with enum casts), curveInfo, 16 IMU fields, calOverrides, tiltOverrides |

### `config/ScsToRos2Bridge.rb`
- Added `"LpsSaNvmCalOnTheFlyDataChannelOutput"` binding

### `config/LpsSaWeighApp.rb`
- Removed `"LpsSaNvmCalOnTheFlyDataChannelOutput"` binding
