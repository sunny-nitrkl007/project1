# CalMgrCmdResp — Port Summary

**Direction:** WeighApp (ROS2 publisher) → ScsToRos2Bridge → AIS SCS → ACD consumer  
**Commit:** `d00c1088`  
**Branch:** `CPM_Porting_WeighDebugChannel`

## Context
ACD (`AutonomyConditionDiagnostics`) is out-of-scope and consumes CalMgrCmdResp on AIS SCS. WeighApp now publishes via ROS2; bridge reads and forwards to AIS SCS.

## What changed

### `apps/LpsSaWeighApp/LpsSaWeighApp.h`
- Removed `CalMgrCmdRespOutput* LpsCalCmdScsRespOut`
- Added `ros2_wrapper::RosOutputInterface<weigh_app_interfaces::msg::CalMgrCmdResp>* calCmdRespRosOut_`
- Removed `#include <interfaces/CalMgrCmdResp/InterfaceTypes.h>`
- Added `#include <weigh_app_interfaces/msg/cal_mgr_cmd_resp.hpp>`

### `apps/LpsSaWeighApp/LpsSaWeighApp.cpp`
| Location | Change |
|---|---|
| Constructor | `LpsCalCmdScsRespOut(nullptr)` → `calCmdRespRosOut_(nullptr)` |
| `initialize()` | Removed `InterfaceDb::bind("CalMgrCmdRespOutput", ...)` → `new RosOutputInterface<CalMgrCmdResp>(rosNode_, "cal_mgr_cmd_resp")` |
| `LpsSaWeighCalReqstCallback()` | `CalMgrCmdResp calMgrCmdResp` → `weigh_app_interfaces::msg::CalMgrCmdResp calMgrCmdResp`. Fields: `CalibrationResp.*` → `calibration_resp.*` (snake_case). Enum casts added. Publishes via `calCmdRespRosOut_->publish(calMgrCmdResp)`. |

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added includes: `cal_mgr_cmd_resp.hpp`, `CalMgrCmdResp/InterfaceTypes.h`
- Added SCS member: `CalMgrCmdRespOutput* calMgrCmdRespScsOut_`
- Added ROS2 member: `unique_ptr<RosInputInterface<CalMgrCmdResp>> calMgrCmdRespRosIn_`
- Added declaration: `static CalMgrCmdResp convertCalMgrCmdRespToScs(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `calMgrCmdRespScsOut_(nullptr)`, `calMgrCmdRespRosIn_()` |
| `initialize()` | Bind `CalMgrCmdRespOutput`; `make_unique` for `calMgrCmdRespRosIn_` |
| `executive()` | Drain loop: reads ROS2 → publishes AIS SCS via `convertCalMgrCmdRespToScs()` |
| End of file | `convertCalMgrCmdRespToScs()` — 6 fields with enum casts (`LpsSaCalRespCode_t`, `CAL_MGR_MR_E`) |

### `config/ScsToRos2Bridge.rb`
- Added `"CalMgrCmdRespOutput"` binding

### `config/LpsSaWeighApp.rb`
- Removed `"CalMgrCmdRespOutput"` binding
