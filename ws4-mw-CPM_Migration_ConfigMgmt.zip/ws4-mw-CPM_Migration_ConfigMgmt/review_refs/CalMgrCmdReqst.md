# CalMgrCmdReqst — Port Summary

**Direction:** ACD (AIS SCS producer) → ScsToRos2Bridge → ROS2 → WeighApp (subscriber)  
**Commit:** `d00c1088`  
**Branch:** `CPM_Porting_WeighDebugChannel`

## Context
ACD (`AutonomyConditionDiagnostics`) is out-of-scope and remains on AIS SCS. Bridge reads the cmd from AIS SCS and forwards to WeighApp via ROS2.

## What changed

### `apps/LpsSaWeighApp/LpsSaWeighApp.h`
- Removed `CalMgrCmdReqstInput* LpsCalCmdScsReqstIn`
- Added `rclcpp::Subscription<weigh_app_interfaces::msg::CalMgrCmdReqst>::SharedPtr calCmdReqstSub_`
- Removed `#include <interfaces/CalMgrCmdReqst/InterfaceTypes.h>`
- Added `#include <weigh_app_interfaces/msg/cal_mgr_cmd_reqst.hpp>`
- Callback signature changed: `void LpsSaWeighCalReqstCallback()` → `void LpsSaWeighCalReqstCallback(const weigh_app_interfaces::msg::CalMgrCmdReqst::SharedPtr msg)`

### `apps/LpsSaWeighApp/LpsSaWeighApp.cpp`
| Location | Change |
|---|---|
| Constructor | `LpsCalCmdScsReqstIn(nullptr)` → `calCmdReqstSub_(nullptr)` |
| `initialize()` | Removed `InterfaceDb::bind` + `addNewDataSlot` → `rosNode_->create_subscription<CalMgrCmdReqst>("cal_mgr_cmd_reqst", QoS(5), std::bind(...))` |
| `LpsSaWeighCalReqstCallback()` | Signature takes `SharedPtr msg`. Removed `while (get())` loop — ROS2 callback fires once per message. `calMgrCmdReq.CalibrationRequest.*` → `msg->calibration_request.*`. `CalIterm` memcpy via `calIterm.data()` with size guard. |

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added includes: `cal_mgr_cmd_reqst.hpp`, `CalMgrCmdReqst/InterfaceTypes.h`
- Added SCS member: `CalMgrCmdReqstInput* calMgrCmdReqstScsIn_`
- Added ROS2 member: `unique_ptr<RosOutputInterface<CalMgrCmdReqst>> calMgrCmdReqstRosOut_`
- Added declaration: `static weigh_app_interfaces::msg::CalMgrCmdReqst convertCalMgrCmdReqstToRos(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `calMgrCmdReqstScsIn_(nullptr)`, `calMgrCmdReqstRosOut_()` |
| `initialize()` | Bind `CalMgrCmdReqstInput`; `make_unique` for `calMgrCmdReqstRosOut_` |
| `executive()` | Drain loop: reads AIS SCS → publishes ROS2 via `convertCalMgrCmdReqstToRos()` |
| End of file | `convertCalMgrCmdReqstToRos()` — 5 scalar fields + `CalIterm` vector resize/copy using `CAL_LAST_ITERM_BIT` |

### `config/ScsToRos2Bridge.rb`
- Added `"CalMgrCmdReqstInput"` binding

### `config/LpsSaWeighApp.rb`
- Removed `"CalMgrCmdReqstInput"` binding
