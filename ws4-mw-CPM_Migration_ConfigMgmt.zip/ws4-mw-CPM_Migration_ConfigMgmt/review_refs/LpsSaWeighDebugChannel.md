# LpsSaWeighDebugChannel — Port Summary

**Direction:** WeighApp → ROS2 → ScsToRos2Bridge → AIS SCS → aisXcpServer  
**Commit:** `759a243b`  
**Branch:** `CPM_Porting_WeighDebugChannel`

## What changed

### `apps/LpsSaWeighApp/LpsSaWeighApp.h`
- Removed `LpsSaWeighDebugChannelOutput* LpsSaWeighScsDebugOut`
- Added `ros2_wrapper::RosOutputInterface<weigh_app_interfaces::msg::LpsSaWeighDebugChannel>* LpsSaWeighDebugRosOut_`
- Added `#include <weigh_app_interfaces/msg/lps_sa_weigh_debug_channel.hpp>`

### `apps/LpsSaWeighApp/LpsSaWeighApp.cpp`
| Location | Change |
|---|---|
| Constructor | `LpsSaWeighScsDebugOut(nullptr)` → `LpsSaWeighDebugRosOut_(nullptr)` |
| `initialize()` | Removed `InterfaceDb::bind("LpsSaWeighDebugChannelOutput", ...)` → added `new RosOutputInterface<...>(rosNode_, "lps_sa_weigh_debug_channel")` |

### `apps/LpsSaWeighApp/LpsSaScs.cpp`
| Function | Change |
|---|---|
| `LpsSaWeighScsDebugTx()` | Guard changed to `if (!LpsSaWeighDebugRosOut_) { return; }`. Builds `weigh_app_interfaces::msg::LpsSaWeighDebugChannel txOut` with 127 field mappings. Publishes via `LpsSaWeighDebugRosOut_->publish(txOut)`. `DebugLpsSaXCPChannels.m_LpsWrk` retained for WRW comparison logic. |

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.h`
- Added includes: `lps_sa_weigh_debug_channel.hpp`, `LpsSaWeighDebugChannel/InterfaceTypes.h`
- Added SCS member: `LpsSaWeighDebugChannelOutput* weighDebugScsOut_`
- Added ROS2 member: `unique_ptr<RosInputInterface<LpsSaWeighDebugChannel>> weighDebugRosIn_`
- Added declaration: `static LpsSaWeighDebugChannel convertWeighDebugToScs(...)`

### `apps/ScsToRos2Bridge/ScsToRos2Bridge.cpp`
| Location | Change |
|---|---|
| Constructor | Init `weighDebugScsOut_(nullptr)`, `weighDebugRosIn_()` |
| `initialize()` | Bind `LpsSaWeighDebugChannelOutput`; `make_unique` for `weighDebugRosIn_` |
| `executive()` | Drain loop: ROS2 → AIS SCS publish via `convertWeighDebugToScs()` |
| End of file | `convertWeighDebugToScs()` — 127-field reverse mapping |

### `config/ScsToRos2Bridge.rb`
- Added `"LpsSaWeighDebugChannelOutput"` binding

### `config/LpsSaWeighApp.rb`
- Removed `"LpsSaWeighDebugChannelOutput"` binding

## Known Note
`DebugLpsSaXCPChannels` (AIS struct) remains as an internal staging struct inside WeighApp — used by business logic files for WRW comparison. It is no longer bound to or published on AIS SCS. Removing it requires refactoring 4 business logic files (out of scope).
