/*******************************************************************************
** COPYRIGHT (C) 2016-2017 CATERPILLAR INC. ALL RIGHTS RESERVED.
--------------------------------------------------------------------------------
FILE NAME: LpsSaJobMgrApp.h
DESCRIPTION:
*******************************************************************************/
/*******************************************************************************
** -- #Include's --
*******************************************************************************/
#ifndef LPSSAJOBMGRAPP_H
#define LPSSAJOBMGRAPP_H

#include <string>
#include <deque>
#include <chrono>

#include <boost/filesystem.hpp>

#ifndef __LPS_COMMON_TYPE_DEF_H__
#include <LpsCommonTypeDef.h>
#endif

#ifndef __LPS_COMMON_STRUCTURES_H__
#include <LpsCommonStructures.h>
#endif

#ifndef __LPS_PT_PUBLIC_H__
#include <LpsPtPublic.h>
#endif
#include <LpsPrivate.h>

#include "JobMgrTxData.h"
#include "JobMgrLoadRecord.h"
 
/*Additional ROS2 interfaces*/
#include <interfaces/LpsSaWeighReqstChannel/DDSWeighAppInf.hpp>
#include "rclcpp/rclcpp.hpp"
#include "ros2wrapper/RosInputInterface.h"
#include "ros2wrapper/RosOutputInterface.h"
#include "ros2wrapper/Ros2TaskWrapper.h"
#include "cpm_common_interfaces/msg/lps_sa_weigh_reqst_channel.hpp"
#include <cpm_common_interfaces/msg/weigh_reqst_channel_command.hpp>
#include <cpm_common_interfaces/msg/shm_clock_input.hpp>
#include <cpm_common_interfaces/msg/lps_sa_ui_display_state_interface.hpp>
#include <cpm_common_interfaces/msg/lps_sa_weigh_resp_channel.hpp>
#include <cpm_common_interfaces/msg/lps_sa_weigh_tx_channel.hpp>
#include <cpm_common_interfaces/msg/lps_sa_job_mgr_reqst_channel.hpp>
#include <job_mgr_interfaces/msg/lps_sa_job_mgr_resp_channel.hpp>
#include <cpm_common_interfaces/msg/ais_jhm2_tx_channel.hpp>
#include <job_mgr_interfaces/msg/lps_sa_load_record_channel.hpp>
#include <job_mgr_interfaces/msg/switch_input_scs.hpp>
#include <job_mgr_interfaces/msg/data_link_data.hpp>
#include <job_mgr_interfaces/msg/event_diagnostic_data.hpp>
#include <cpm_common_interfaces/msg/autonomy_condition_diagnostics_tx_channel.hpp>
#include <job_mgr_interfaces/msg/lps_sa_job_mgr_tx_channel.hpp>
#include <job_mgr_interfaces/msg/lps_sa_job_mgr_debug_channel.hpp>
#include <job_mgr_interfaces/msg/output_channel.hpp>

#include "LpsSaJobMgrTasks.h"
#include "LpsSaJobMgrCnfg.h"
#include "LpsSaJobMgrStats.h"
#include "LpsSaJobMgrSimpleCal.h"

/*******************************************************************************
** -- #Define, Struct's, Typedef's, Enum's --
*******************************************************************************/
//#define DEBUG

#define SUCCESS           (boolean) 1
#define FAIL              (boolean) 0

#define TEMP_STORAGE_ROOT (R"(/tmp/appdata/CPM/LpsSaJobMgrApp/)")

typedef enum
{
    LPS_SA_JOB_MGR_SCS_RESP_RECVD = 0,
    LPS_SA_JOB_MGR_SCS_RESP_INCORRECT,
    LPS_SA_JOB_MGR_SCS_RESP_NOT_RECVD,
    LPS_SA_JOB_MGR_SCS_RESP_UNKNOWN_ERR
} LpsSaJobMgrScsChkCmdResponseStat_t;

typedef enum
{
    LPS_SA_JOB_MGR_INIT_SUCCESS = 0,
    LPS_SA_JOB_MGR_SCS_INIT_ERROR,
    LPS_SA_JOB_MGR_PT_INIT_ERROR,
} LpsSaJobMgrInitErrorType_t;


class LpsSaJobMgrApp: public ros2_wrapper::Ros2TaskWrapper
{
public:
    LpsSaJobMgrApp( const std::string& taskName );
    ~LpsSaJobMgrApp( ) override;

    bool initialize( ) override;
    bool executive( ) override;
    void cleanup( ) override;
    void startExecutiveTimer( ) override;

protected:
    inline std::string makeStoragePath(const std::string& fileName) const {
        return (storageRoot_ / fileName).string();
    }

private:

    struct LpsJobMgrJobTrackerInfoTbl_t {
        jobmgr_data::LpsSaJobMgrManualTipOffState_t ManualTipOffState = jobmgr_data::LPS_SA_JOB_MGR_MAN_TIP_OFF_UNAVAILABLE;
        jobmgr_data::LpsSaJobMgrTipOffState_t TipOffState = jobmgr_data::LPS_SA_JOB_MGR_TIP_OFF_UNAVAILABLE;
        jobmgr_data::LpsSaJobMgrOperationMode_t OperationMode = jobmgr_data::LPS_SA_JOB_MGR_WEIGH_MODE;
        jobmgr_data::DispBestBktWt_t DispBestBktWt = { 0.f, false };
        LpsWeighBktDigStat_t DigStat = LPS_WEIGHT_BKT_DIG_STATE_UNKNOWN; /* Machine Dig Status */
        LpsWeighCalStatus_t CalStat = LPS_WEIGH_SYSTEM_CALIBRATED; /* Lps System Calibration Status */
        LpsWeighBktDumpStat_t DumpStat = LPS_WEIGHT_BKT_DUMP_STATE_UNKNOWN; /* Machine Dump Status */
        jobmgr_data::ReqPloadCtrlSysStat_t ReqPloadCtrlSysStat = jobmgr_data::ReqPloadCtrlSysStat_t::NONE;
        bool TipoffAssistActive = false;
        bool TipoffAssistPIDActive = false;
        uint_fast16_t TipoffAssistActiveEid = 0;
        bool ManualAddPIDActive = false;
        bool ManualAddPIDPreviouslyDepressed = false;
        bool StorePIDActive = false;
        bool StorePIDPreviouslyDepressed = false;
        unsigned int storePressCount = 0;
        float zeroWeight = 0.f;
        float simpleCalAdjust = 1.f;
        bool splitModeNextPayloadCmd = false;
        uint16_t subtotalIndex;
        bool selectSubtotalCmd = false;
        bool lftSealed = false;
        bool memoryFull = false;
        bool inVerificationMode = false;
    };

    /* SHM and Time Zone */
    uint_least32_t serviceHourMeter_;
    struct {
        int32_t offset;
        int32_t index;
    } tzInfo_;

    LpsPtInputs_t                    LpsSaJobMgrWmInput;
    LpsPtOutputs_t                   LpsSaJobMgrWmOutput;

    LpsJobMgrJobTrackerInfoTbl_t     LpsJobMgrJobTrackerInfoTbl;

    /*SCS  Interfaces*/
    ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::LpsSaJobMgrTxChannel>* LpsSaJobMgrTxRosOut_;
    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel>* LpsSaJobMgrReqstIn;
    ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::LpsSaJobMgrDebugChannel>* LpsSaJobMgrDebugRosOut_;
    ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::LpsSaJobMgrRespChannel>* LpsSaJobMgrRespChannelOutput_;

    bool weighAppTxDataReceived_;
    DDSWeighAppInf weighAppInf_; // WeighApp Interface
    ros2_wrapper::RosOutputInterface<cpm_common_interfaces::msg::LpsSaWeighReqstChannel>* weighReqstOut_;
    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::LpsSaWeighRespChannel>* weighRespIn_;
    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::LpsSaWeighTxChannel>* weighTxIn_;

    // executiveTimer_ now lives in Ros2TaskWrapper (base class).

    ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::SwitchInputScs>* LpsSaSwitchInput;
    ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::OutputChannel>* LpsSaOutputChannelRosOut_;

    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::AisJhm2TxChannel>* AisJhm2TxInput;

    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::LpsSaUIDisplayStateInterface>* displayStateInputRos_;

    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::ShmClockInput>* ShmClockInputRos;

    ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::DataLinkData>* dataLinkDataInputRos_;

    ros2_wrapper::RosOutputInterface<job_mgr_interfaces::msg::LpsSaLoadRecordChannel>* loadRecordOutputChannel_;

    LpsSaJobMgrTasks tasks_;

    LpsSaJobMgrCnfg config_;

    LpsSaJobMgrStats stats_;

    LpsSaJobMgrSimpleCal simpleCal_;

    boost::filesystem::path storageRoot_;

    float defaultTargetWeight_;

    std::string machineMSN;

    std::chrono::steady_clock::time_point storeRejectedExpireTime;

    ros2_wrapper::RosInputInterface<cpm_common_interfaces::msg::AutonomyConditionDiagnosticsTxChannel>* autonomyConditionDiagnosticsTxInputRos_;
    bool SEALevel1EssentialsInstalled_;
    bool SEALevel2ProInstalled_;
    bool SEALegalForTradeInstalled_;

    ros2_wrapper::RosInputInterface<job_mgr_interfaces::msg::EventDiagnosticData>* eddtInputRos_;

    bool loadOldLoadRecord(jobmgr_data::LpsSaLoadRecordChannelStorage& loadRecord);

    bool saveConfig(void);

    bool parseUiConfigurableFeatures(void);	// check if Show/Hide config has tip-off disabled

    void cleanupRosInterfaces();

    void LpsSaJobMgrPtInit(void);/* Pass tracker lib Initialization*/
    boolean LpsSaJobMgrPtUpdate(void);/*Job Manager App Pt Lib Update*/
    void LpsSaJobMgrPtRestoreTruck(void);

    /*SCS  Functions*/
    void LpsSaWeighScsTxParamRead(void);/*get parameters from weighing app*/
    void LpsSaJobMgrScsChkForReqst(void);/*get request from UI*/

    boolean LpsSaJobMgrScsRx(void);/*get parameters from weighing app*/
    boolean LpsSaJobMgrScsTx(void);/*write param to UI*/
    void LpsSaJobMgrScsSendCmd(cpm_common_interfaces::msg::WeighReqstChannelCommand::_value_type command); /* send command to weighing app */
    void LpsSaJobMgrSendCmdToWeighApp(void);
    void LpsSaJobMgrHandleTipOffBtnStates(void);
    void AisJhmDataServerTxRead(void);
    void LpsSaJobMgrScsSHMRead(void);
    void LpsSaJobMgrScsDataLinkDataRead(void);
    void LpsSaJobMgrScsEddtRead();
    bool sendReqstResponse(const cpm_common_interfaces::msg::LpsSaJobMgrReqstChannel& request, bool success);
    jobmgr_data::ReqPloadCtrlSysStat_t GetActiveButtonStatus (void);
    void LpsSaJobMgrScsChkHornAction(void);
    bool LpsSaJobMgrHornOnStoreAction(void);

    // Reset LpsPtInputs flags
    void resetLpsPtInputFlags(void);

    /* Load record conversion: AIS SCS -> ROS2 msg, for publishing via loadRecordOutputChannel_ */
    static job_mgr_interfaces::msg::LpsSaLoadRecordChannel convertLoadRecordToRos(const jobmgr_data::LpsSaLoadRecordChannelStorage& scs);
    static job_mgr_interfaces::msg::LpsSaJobMgrTxChannel convertJobMgrTxToRos(const jobmgr_data::JobMgrTxData& scs);

    LpsWeighBktWtAccuracy_t totalWeightAccuracy_;

    enum class LftStoreAllowedStatus_t { ALLOW_STORE, REJECT_STORE_MEMORY_FULL, REJECT_STORE_LOW_ACCURACY };

    // Disable store for LFT when accuracy below High accuracy OR memory is full
    // When LFT is not sealed accuracy can not exceed ACCURACY_MED
    inline LftStoreAllowedStatus_t getLftStoreAllowedStatus() {
        if (SEALegalForTradeInstalled_) {
            if (LpsJobMgrJobTrackerInfoTbl.memoryFull) {
                return LftStoreAllowedStatus_t::REJECT_STORE_MEMORY_FULL;
            }
            else if (tasks_.currentTaskGetLFTDisable()) {
                return LftStoreAllowedStatus_t::ALLOW_STORE;
            }
            else if (totalWeightAccuracy_ < LPS_WEIGH_BUCKET_WEIGHT_ACCURACY_HIGH) {
                return LftStoreAllowedStatus_t::REJECT_STORE_LOW_ACCURACY;
            }
            else {
                return LftStoreAllowedStatus_t::ALLOW_STORE;
            }
        }
        else {
            return LftStoreAllowedStatus_t::ALLOW_STORE;
        }
    }
};

#endif
